### A Pluto.jl notebook ###
# v0.20.3

using Markdown
using InteractiveUtils

# This Pluto notebook uses @bind for interactivity. When running this notebook outside of Pluto, the following 'mock version' of @bind gives bound variables a default value (instead of an error).
macro bind(def, element)
    #! format: off
    quote
        local iv = try Base.loaded_modules[Base.PkgId(Base.UUID("6e696c72-6542-2067-7265-42206c756150"), "AbstractPlutoDingetjes")].Bonds.initial_value catch; b -> missing; end
        local el = $(esc(element))
        global $(esc(def)) = Core.applicable(Base.get, el) ? Base.get(el) : iv(el)
        el
    end
    #! format: on
end

# ╔═╡ 292dd262-a364-11eb-053a-8169f9613c46
begin
	using Ferrite
	using FerriteGmsh
	using FerriteViz
	using Tensors
	using SparseArrays
	import GLMakie
end

# ╔═╡ 9c3718e9-10bc-4599-8042-ff803367b75a
begin
	using PlutoUI
	PlutoUI.TableOfContents(title="Exercise 3")
end

# ╔═╡ e52318f4-a34a-11eb-0a99-7936c0dd356d
md"""# Mechanical Modeling of Materials – Exercise 3
Welcome to the first hands on programming session of *Mechanical Modeling of Materials*. In this session we are going to implement a **linear elastic, isotropic material law** and use it in a finite element simulation.
"""

# ╔═╡ 797799fa-6418-40e7-a952-9420fb66138c
md"""
These are the plots we saw in the last task of the previous exercise:
"""

# ╔═╡ 1065fc10-a365-11eb-3853-e38bf36935d0
function create_sigma_eps_measure_plots()
	λ = 42 # GPa
	μ = 62.5 # GPa
	ν = λ/(2*(λ+μ))
	ε11 = 0:0.0002:0.010
	ε = [ fromvoigt(SymmetricTensor{2,3},[ϵ, -ϵ*ν, -ϵ*ν,0.0,0.0,0.0]) for ϵ in ε11 ]
	σ = [ λ * tr(ϵ) * one(SymmetricTensor{2,3}) + 2μ * ϵ for ϵ in ε ]
	
	Figure = GLMakie.Figure
	Axis = GLMakie.Axis
	lines! = GLMakie.lines!
	
	fig = Figure()
	ax1 = Axis(fig[1,1], title="Stress over Strain", xlabel="ε₁₁ in [‰]", ylabel="σ₁₁ in [GPa]")
	ax2 = Axis(fig[1,2], title="Strain over Strain", xlabel="ε₁₁ in [‰]", ylabel="-ε₂₂/-ε₃₃ in [‰]")
	
	lines!(ax1, getindex.(ε,1,1) *1000 , getindex.(σ,1,1))
	lines!(ax2, getindex.(ε,1,1) *1000 , -getindex.(ε,2,2)*1000)

	return fig
end;

# ╔═╡ a1306504-a366-11eb-2c57-df5b43eb08c8
create_sigma_eps_measure_plots()

# ╔═╡ 6e024264-a36c-11eb-3a5b-f1ac308746bc
md"""
### Part 1 – Implementing the Constitutive Equation

The material law is usually implemented in a seperate function, usually called *materialSubRoutine* or something similar. The complexity of the function depends on the material model being implemented.
Over the next few weeks, we will concretely implement a few material models (in increasing order of complexity) and use them to solve boundary value problems in the finite element program [Ferrite.jl](https://ferrite-fem.github.io/Ferrite.jl).
"""

# ╔═╡ 445a67b9-8825-4235-85e7-b8c9fe1b9f64
md"""
For today's linear isotropic model, let's use the same Lamé parameters $λ$ and $μ$ we calculated in the last task of the previous exercise. Enter the values you calculated in the corresponding fields below:
"""

# ╔═╡ 10886362-a368-11eb-259c-b7fc8584e201
λ = Missing

# ╔═╡ 2d58ce80-a368-11eb-1cac-abbc689d8924
μ = Missing

# ╔═╡ 8ed6aed4-a37a-11eb-2437-ab230e0d7961
md"""
Let's *define* a structure(using the `struct` keyword) called `Elasticity` that contains the the Lamé Parameters. We define λ and μ as 64-bit double-precision numbers.
"""

# ╔═╡ 4b19b7d6-a372-11eb-053a-6b9b98cf740b
struct Elasticity
	λ::Float64
	μ::Float64
end

# ╔═╡ 997381cf-78cd-4135-8afa-b45b8cb6ca13
md"""
We then *instantiate* an object of type `Elasticity` using the Lamé parameter values defined above:
"""

# ╔═╡ 87655cba-16d6-4103-830e-e82c83c10ac2
md"""
We calculate the Poisson-Ration $\nu$ using the equation $\nu = \dfrac{\lambda}{2\,(\lambda+\mu)}$
"""

# ╔═╡ 456aafaa-a374-11eb-140e-af2e4385326d
md"""
To test the material routine, we use fictitious test data. In this case, we use the same data that we used to determine the material parameters.
"""


# ╔═╡ 25578ccc-a374-11eb-1fdc-47e4266e88bd
ε11 = 0:0.0002:0.01 # This is an array with three double values

# ╔═╡ 8eecc8d1-cc5a-4c87-afb7-fe8d38678d55
md"""
Note: The finite element program *Ferrite* provides a class `Tensor` which lets us use a notation in our code that is very close to the symbolic tensor notation.
Here's how a `SymmetricTensor` is constructed, just as an example.
"""

# ╔═╡ 94c1a07c-6a15-4814-b0f4-74187016c0fc
md"""
And here we construct an `Array` of `SymmetricTensors`, one for each value in `ε11`
"""

# ╔═╡ 48516bec-071e-4aff-a535-e03a6e4c0144
md"""
### Task 3.1 - Complete the function below
We want to calculate the stress $\boldsymbol{σ}$ and the material tangent $\boldsymbol{\mathbb{C}}$ as a function the generated vector of strains $\boldsymbol{\varepsilon}$. To do this we define a function called `materialLaw()` that takes in the vector of strains and an object of type `Elasticity` and returns the stress tensor and the material tangent.
"""

# ╔═╡ e0b3343e-4057-40fa-a23a-127b27c28c52
md"""
Implement the following equations into the function `materialLaw()` such that it returns the stress tensor and the material tangent: 

$\boldsymbol{\sigma} = \lambda \operatorname{tr}(\varepsilon) \boldsymbol{I} + 2\,\mu\,\boldsymbol{\varepsilon},$

$\boldsymbol{\mathbb{C}} = \lambda\,\boldsymbol{I}\otimes\boldsymbol{I} + 2\,\mu\, \mathbb{I}.$
"""

# ╔═╡ 826f5b04-a36c-11eb-03d1-8f5982edfebe
function materialLaw(ε::SymmetricTensor{2,dim}, material::Elasticity) where {dim}
    λ = material.λ
    μ = material.μ
    I = one(SymmetricTensor{2,dim}) # Identity of 2nd Order
    II = one(SymmetricTensor{4,dim}) # Identity of 4th Order

    # Calculate σ and ℂ here

	σ = Missing
	ℂ = Missing

    return σ, ℂ
end;

# ╔═╡ bc8f9306-a41a-11eb-0ffd-178dcb88d385
md"""

This is your material tangent stiffness matrix  $\mathbb{C}$ in voigt notation:
"""

# ╔═╡ a572e9be-a377-11eb-1e31-e158b0432f7b
begin
	md"""
	We plot the result using the analytical solution for a simple uniaxial stretch test:
	"""
end

# ╔═╡ 3fe0af28-a395-11eb-0b07-330e4db0bda2
md"""
### Part 2 - Using the material routine in a simple FEM program

Now that we have implemented the material routine, we can use it in a finite element program. What follows is a small recap of the *finite element method*.

#### FEM basics
"""

# ╔═╡ 8d40faae-a3aa-11eb-1fc9-9d64b9cd7f90
md"""

##### The Weak Form

In FEM, partial differential equations are transformed to the integral form or "weak form". In the case of linear elasticity the balance of momentum in the weak form is described as:

```math
	\int_{\mathcal{B}} \delta\boldsymbol{\varepsilon} \colon \underbrace{\mathbb{C} \colon \boldsymbol{\varepsilon}}_{\boldsymbol{\sigma}} \ \text{d} V = \int_{\mathcal{B}} \delta \boldsymbol{u} \cdot \boldsymbol{b} \ \text{d} V + \int_{\partial\mathcal{B}} \delta \boldsymbol{u} \cdot \boldsymbol{t} \ \text{d} A \qquad \forall \delta \boldsymbol{u}
```

To solve the boundary value problem, certain constraints are necessary. On certain parts of the boundary called "Dirichlet boundary", the solution is prescibed

```math
	\boldsymbol{u}(\boldsymbol{x}) = \bar{\boldsymbol{u}}(\boldsymbol{x}) \qquad \forall \boldsymbol{x} \in \partial \mathcal{B}
```
where $\bar{\boldsymbol{u}}(\boldsymbol{x})$ are the prescribed values and $\partial \mathcal{B}$ is the Dirichlet boundary.
"""


# ╔═╡ 715eabba-a3a7-11eb-0655-3b3866454bd2
md"""
##### Discretization of the Domain

In FEM, the real solution that exists in an infinite dimensional space is approximated by a finite-dimensional version. This is accomplished by dividing the domain into a set of discrete sub-domains called elements that together make up a *Mesh*. Evaluation of the integrals is then done element wise. In *Ferrite*, the results of these integrals are stored in the classes

```julia
	CellValues
	CellVectorValues
```
Objects of this class contain the element-wise data such as Shape Functions and their Gradients.
"""

# ╔═╡ de4730e3-cb4a-45f8-a72d-b80bc67f6835
md"""
##### Function Interpolation
Interpolation is used to create a continious function using known values at 'support points' or 'nodes'. This interpolated function can then be manipulated, for example by computing its gradient.

In *Ferrite*, we have the class
```julia
Lagrange{dim, RefShape, order}()
```

which implements the Lagrange polynomial interpolation function. Here, `dim` is the dimension of the euclidian space, `RefShape` is the type of element (e.g. `RefTetrahedron` for tetrahedral elements or `RefCube` for hexahedral elements) and `order` refers to the polynomial order (e.g. $x^2+x+1$ has `order=2`)
"""

# ╔═╡ 0de006b6-a3a6-11eb-3bfb-e5983d01d5d2
md"""

##### Numerical Integration
Since we use the weak form of the balance equations, there are always intergrals we need to compute. Since polynomial integration is not so feasible on a computer, we use numerical integration. The integral of the function is thus replaced by a weighted sum of the function at discrete points as follows

$$\int_{\Omega} f(\boldsymbol{x}) \, \text{d}\Omega \approx \sum_{\text{gp}=1}^{n_\text{gp}} f(\boldsymbol{x}_{\text{gp}}) \, w_{\text{gp}}.$$

Here, $\boldsymbol{x}_{\text{gp}}$ is a point in space, $w_{\text{gp}}$ is a scalar weight, and $n_{\text{gp}}$ is the number of integration points. There are several integration rules available depending on the function to be integrated. Usually for polynomials, the Gaussian Integration scheme is used.
"""

# ╔═╡ 2f29c296-a3a6-11eb-1933-9d3be03a3367
md"""
We can make use of the pre-written integration rules in *Ferrite* using the class
```julia
QuadratureRule{dim, RefShape}(order)
``` 
"""

# ╔═╡ 381068d6-4424-446c-92bd-3751cea78edf
md"""
##### Assembly

The concept of spatial discretization is now applied to the weak form by splitting up the integrals. We integrate over the elements and sum up the results

```math
	\sum_{e \in \mathcal{B}} \int_{\mathcal{B}_e} \delta \boldsymbol{\varepsilon} : \boldsymbol{\mathbb{C}} : \boldsymbol{\varepsilon} \, \text{d}V 
		= \sum_{e\in\mathcal{B}} \int_{\mathcal{B}_e} \delta \boldsymbol{u} \cdot \boldsymbol{b} \, \text{d}V 
			+ \sum_{e\in\mathcal{B}} \int_{∂\mathcal{B}^e} \delta \boldsymbol{u} \cdot \boldsymbol{t} \, \text{d} A.
```

Now we use the shape functions of the function interpolation which in our case take the form

```math
	\boldsymbol{u} \approx \boldsymbol{u}^h = \sum_i \boldsymbol{N}_i d_i
```

where $\boldsymbol{N}_i$ is the shape function for the i-th degree of freedom and $d_i$ is the nodal value of the i-th degree of freedom. For an element which is a 2D Triangle we would have three nodes and two degrees of freedom per node. This leads to six degrees of freedom $i=1,...,6$ so the nodal values would look like $d_i\in\{d_{1x},d_{1y},...,d_{3y}\}(=\boldsymbol{d}_e)$. For the strain $\boldsymbol{\varepsilon}$ we get

```math
\boldsymbol{\varepsilon} \approx \boldsymbol{\varepsilon}^h = \text{grad}^{\mathrm{sym}} \, \boldsymbol{u}^h = \sum_i  \text{grad}^{\mathrm{sym}}(\boldsymbol{N}_i) d_i.
```

Here, we use the Galerkin Method in which the shape-functions and the test-functions are chosen to be the same 

```math
	\delta \boldsymbol{\varepsilon} := \sum_i \text{grad}^{\mathrm{sym}}(\boldsymbol{N}_i) \, d_i
	\quad \text{ und }
	\quad \delta \boldsymbol{u} := \sum_i \boldsymbol{N}_i d_i.
```

Putting all of this into the weak form, we obtain

```math
	\sum_{e \in \mathcal{B}} \int_{\mathcal{B}_e} \sum_{i,j} 
			d_i \ \underbrace{
			\text{grad}^{\mathrm{sym}}(\boldsymbol{N}_i) : \mathbb{C} : \text{grad}^{\mathrm{sym}}(\boldsymbol{N}_j)}_{\boldsymbol{k}^e} \ d_j \, \text{d}V 
```
```math
		= \sum_{e\in\mathcal{B}} 
			\underbrace{
			\int_{\mathcal{B}_e} 
			\sum_i d_i \boldsymbol{N}_i \cdot \boldsymbol{b} \, \text{d}V 
			+ \int_{∂\mathcal{B}^e_t} d_i \sum_i \boldsymbol{N}_i \cdot \boldsymbol{t} \, \text{d} A
			}_{\boldsymbol{f}^e}.
```

This is only an outline of the assembly scheme. What is missing is the more complicated Newton-Raphson scheme. You will learn more about it in your FEM lectures.
"""

# ╔═╡ 56800fba-2faa-4046-9fbb-66d51c8a9c60
md"""
#### Our Boundary Value Problem
"""

# ╔═╡ da71a160-0046-4d08-a83a-826a712a1c2a
begin
	LocalResource("./bvp.png")
end

# ╔═╡ f23ecb85-4c21-42c1-99dd-bf2a26dd48fd
md"""
The following function is used to generate the mesh. You can configure the element-size using the parameter `lc`
"""

# ╔═╡ 20a052ab-c1a4-4b67-80e6-00f3fa1c3a2c
function plate_hole(;x::AbstractVector{<:Real}=[0.,0.],
                             dx::AbstractVector{<:Real}=[100.,100.],
                             radius::Real=25.,
                             verbosity::Integer=3,
                             visual::Bool=false,
                             lc::Real=1,
                             algorithm::Integer=6)
	gmsh.initialize()

	gmsh.option.set_number("General.Verbosity", verbosity)
	gmsh.option.set_number("Mesh.Algorithm",algorithm)

	gmsh.model.add("plate_with_hole")

	circle_center = x + [dx[1]/2.0, dx[2]/2.0]

	rectangle = gmsh.model.occ.add_rectangle(x[1],x[2],0.,dx[1],dx[2])

	circle = gmsh.model.occ.add_circle(circle_center[1],circle_center[2],0.,radius)

	circle = gmsh.model.occ.add_curve_loop([circle])

	circle = gmsh.model.occ.add_plane_surface([circle])

	gmsh.model.occ.cut([(2,rectangle)], [(2,circle)])

	gmsh.model.occ.synchronize()

	box = gmsh.model.mesh.field.add("Box")
	gmsh.model.mesh.field.set_number(box, "VIn", lc)
	gmsh.model.mesh.field.set_number(box, "VOut", 2*lc)
	gmsh.model.mesh.field.set_number(box, "XMin", x[1])
	gmsh.model.mesh.field.set_number(box, "XMax", x[1] + dx[1])
	gmsh.model.mesh.field.set_number(box, "YMin", x[2])
	gmsh.model.mesh.field.set_number(box, "YMax", x[2] + dx[2])
	gmsh.model.mesh.field.set_number(box, "Thickness", .1)

	gmsh.model.mesh.field.set_as_background_mesh(box)

	gmsh.model.mesh.generate()

	if visual == true
		gmsh.fltk.run()
	end

	facedim = 1
	voludim = 2
	gmsh.model.mesh.renumberNodes()
	gmsh.model.mesh.renumberElements()
	nodes = tonodes()
	elements, gmsh_elementidx = toelements(voludim)
	cellsets = tocellsets(voludim, gmsh_elementidx)
	boundarydict = toboundary(facedim)
	facesets = tofacesets(boundarydict, elements)

	gmsh.finalize()

	return Grid(elements, nodes, cellsets=cellsets, facesets=facesets)
end;

# ╔═╡ c70094da-e622-4380-993e-bf83a734aff0
grid = plate_hole(lc=5);

# ╔═╡ 94f75fdf-7d1d-48b2-bf49-c0218075abb3
begin
	F = GLMakie.Figure()
	ax =  GLMakie.Axis(F[1, 1],aspect=1)
	wireframe!(ax,grid,markersize=1)
	F
end	

# ╔═╡ 008a130c-b1b2-4c38-a724-add0b5e95fb6
md"""
### Task 3.2 – Complete the assembly code
Study the code and add a call to the material routine `materialLaw` at the appropriate location.  
"""

# ╔═╡ 1540906e-a3ac-11eb-390d-35d34eae5172
function doassemble(cellvalues::CellValues, facevalues::FaceValues,
	dh::DofHandler, material)

	# number of basis functions per cell
	n_basefuncs = getnbasefunctions(cellvalues)

	# local cell-matrices and cell-right-hand-sides
	Ke = zeros(n_basefuncs, n_basefuncs)
	fe = zeros(n_basefuncs)

	# system-matrix K and right-hand-side f
	K = create_sparsity_pattern(dh)
	f = zeros(ndofs(dh))

	# Object for correct assembly
	assembler = start_assemble(K, f)

	# Traction Boundary Conditions
	force = 0.0
	traction = Dict("top" => Vec{2}((0.,force)), "left" => Vec{2}((-force,0.0)), "bottom" => Vec{2}((0.,-force)),"right" => Vec{2}((force,0.)))

	# Body force
	b = Vec{2}((0,0))

	# This variable can be deleted, once the material model is put at the correct spot
	σ = one(Tensor{2, 2})

	# loop over the cells of the mesh
	for cell in CellIterator(dh)
		fill!(Ke, 0)
		fill!(fe, 0)
		reinit!(cellvalues, cell)

		for q_point in 1:getnquadpoints(cellvalues)
			dΩ = getdetJdV(cellvalues, q_point)

			for i in 1:n_basefuncs
				δu  = shape_value(cellvalues, q_point, i)
				δε = shape_symmetric_gradient(cellvalues, q_point, i)

				fe[i] += (δu ⋅ b) * dΩ

				for j in 1:n_basefuncs
					ε = shape_symmetric_gradient(cellvalues,q_point,j)

					
					Ke[i, j] += (δɛ ⊡ σ) * dΩ
				end
        	end
        end

		# loop over the cell surfaces (only needed if surface traction exists)
		for face in 1:nfaces(cell)
			if ((cellid(cell), face) ∈ getfaceset(dh.grid, "left")) ||  ((cellid(cell), face) ∈ getfaceset(dh.grid, "top")) || ((cellid(cell), face) ∈ getfaceset(dh.grid, "bottom")) ||  ((cellid(cell), face) ∈ getfaceset(dh.grid, "right"))
				if ((cellid(cell), face) ∈ getfaceset(dh.grid, "left"))
			 		t = traction["left"]
				elseif((cellid(cell), face) ∈ getfaceset(dh.grid, "top"))
					t = traction["top"]
				elseif((cellid(cell), face) ∈ getfaceset(dh.grid, "right"))
					t = traction["right"]
				elseif((cellid(cell), face) ∈ getfaceset(dh.grid, "bottom"))
					t = traction["bottom"]
				end
				reinit!(facevalues, cell, face)
				for q_point in 1:getnquadpoints(facevalues)
					dΓ = getdetJdV(facevalues, q_point)
					for i in 1:n_basefuncs
						δu = shape_value(facevalues, q_point, i)
						fe[i] += (δu ⋅ t) * dΓ
					end
				end
			end
		end
		
		assemble!(assembler, celldofs(cell), fe, Ke)
	end

	return K,f
end;

# ╔═╡ e5d0ccc8-a409-11eb-2064-dd0f3fabed88
md"""
The function `solve()` contains all the ingredients of the FEM soup: the mesh, the boundary values, the integration rules and the shape functions. At the end, the system of equations $\boldsymbol{K}\boldsymbol{u} = \boldsymbol{f}$ is assembled and solved for $\boldsymbol{u}$.

In the code below, figure out where the material law is used.
"""

# ╔═╡ 85748df5-2f22-4d95-a974-ca9855aa5462
md"""
We then plot the solution using the visualization package *FerriteViz*
"""

# ╔═╡ 6986999a-aae6-41c4-847a-29263d5697cb
md"""
Use this slider to scale the deformation, to see it better in the plot.
"""

# ╔═╡ 648254c4-c8be-4b60-9f49-ea68e449884f
md"""

## Task 3.3 - Transverse Isotropy

The following equations describe the behaviour of a tranversely isotropic, linear elastic material 

```math
\psi = \frac{1}{2} \lambda \ I_1^2 + \mu I_2 + \alpha_1 I_1 I_4 + 2\alpha_2 I_5 + \frac{1}{2} \alpha_3 I_4^2  
```

```math
\implies\sigma = \frac{\partial \psi}{\partial \varepsilon} = \lambda I_1 \mathbf{I} + 2\mu \varepsilon + \alpha_1 (I_4 \mathbf{I}+ I_1 \mathbf{M}) + 2\alpha_2 (\varepsilon \mathbf{M} + \mathbf{M} \varepsilon) + \alpha_3 (I_4 \mathbf{M})
```

```math
\begin{align}
\mathbb{C} &= \frac{\partial^2 \psi}{\partial \varepsilon^2} = \frac{\partial \sigma}{\partial \varepsilon}\\ 
\implies\mathbb{C} &= \lambda \mathbf{I} \otimes \mathbf{I} + 2\mu \mathbb{I} + \alpha_1 (\mathbf{I}\otimes \mathbf{M}+\mathbf{M}\otimes \mathbf{I})+2\alpha_2(\mathbf{I} \otimes \mathbf{M}+\mathbf{M} \otimes \mathbf{I}) + \alpha_3 \mathbf{M} \otimes \mathbf{M}
\end{align}
```

Implement this and compare the solution obtained to the isotropic material.
"""

# ╔═╡ 544f0f72-ee21-4efc-b5db-0bb2d10dee2b
struct TransversalIsotropic{dim}
	λ::Real
	μ::Real
	α₁::Real
	α₂::Real
	α₃::Real
	a::Tensor{1,dim}
end

# ╔═╡ 6c3506c6-16de-42a8-a085-0c611386134b
function materialLaw(ε::SymmetricTensor{2,dim}, material::TransversalIsotropic) where dim
	λ = material.λ
    μ = material.μ
	α₁ = material.α₁
	α₂ = material.α₂
	α₃ = material.α₃
	M = material.a ⊗ material.a
    I = one(SymmetricTensor{2,dim})
    II = one(SymmetricTensor{4,dim})
	
	I₁ = tr(ε)
	I₄ = tr(ε⋅M)

	σ = Missing
	ℂ = Missing
	
	return σ, ℂ
end;

# ╔═╡ 1ecb7048-a377-11eb-3dff-ad2a1c343969
function plot_material(ε::Vector{<:SymmetricTensor{2,dim}}, material::Elasticity) where { dim }

	σ = getindex.(materialLaw.(ε, (material,)), 1)

	ε_11 = getindex.(ε, 1, 1)
	ε_22 = getindex.(ε, 2, 2)
	ε_33 = getindex.(ε, 3, 3)
	
	σ_11 = getindex.(σ, 1)

	Figure = GLMakie.Figure
	Axis = GLMakie.Axis
	lines! = GLMakie.lines!

	fig = Figure()
	
	axis_1 = Axis(fig[1,1],
		title="σ–ε Graph",
		xlabel="ε₁₁ in [‰]",
		ylabel="σ₁₁ in [MPa]")
	
	axis_2 = Axis(fig[1,2],
		title="ε–ε Graph",
		xlabel="ε₁₁ in [‰]",
		ylabel="ε₂₂/ε₃₃ in [‰]")
	
	GLMakie.Label(fig[0,:],
		"Plots of the implemented function",
		fontsize=30)

	lines!(axis_1, ε_11 * 1000,   σ_11)
	lines!(axis_2, ε_11 * 1000, - ε_22 * 1000)

	return fig
end;

# ╔═╡ 103d11d7-efac-4c36-8ac2-d8fdc256b484
begin
	hint(text;blur=true) = blur ? Markdown.MD(
		Markdown.Admonition("hint", "Help"[text])) : Markdown.MD(Markdown.Admonition("note", "Help", [text]))

	warning(text) = Markdown.MD(Markdown.Admonition("warning", "Warning", [text]))

	yays = [ md"Good job! 🐣", md"Yes 👍", md"Splendid! 🎉", md"Nicely done! 🐦",
		md"Well done! 🐤", md"Nice work! 🐧", md"Nice! 🐖", md"Very nice! 🐿" ]

	correct(text=rand(yays)) = Markdown.MD(Markdown.Admonition("correct", "Correct!", 	[text]))
	
	still_missing(text=md"Replace `Missing` with your answer", titel="Not yet! 🦦") =
		Markdown.MD(Markdown.Admonition("warning", titel, [text]))

	keep_working(text=md"This is not the correct answer, try again! 🦥") =
		Markdown.MD(Markdown.Admonition("danger", "Wrong", [text]))

	solution(text; blur=true) = blur ? Markdown.MD(Markdown.Admonition("hint", 
		"Solution", [text])) : Markdown.MD(Markdown.Admonition("note", "Solution", [text]))

	svg(path) = HTML(open(f->read(f, String), path))
end;

# ╔═╡ 14e53455-986a-4d0a-aaad-cf2f0b55aaef
begin
	lame_tol=1e-2;
	if (!(@isdefined λ) || λ === Missing) || (!(@isdefined μ) || μ === Missing)
		lame_correct = false
		still_missing(md"Fill in the values of λ and μ.")
	elseif isapprox(λ, 42, atol=lame_tol) === Missing ? false : isapprox(λ,42, atol=lame_tol) && (μ === Missing)
		lame_correct = false
		correct(md"λ is correct! But μ is not.")
	elseif isapprox(μ,62.5, atol=lame_tol) === Missing ? false : isapprox(μ,62.5, atol=lame_tol) && (λ === Missing)
		lame_correct = false
		correct(md"μ is correct!")
	elseif isapprox(μ,62.5,atol=lame_tol) === Missing ? false : isapprox(μ,62.5,atol=lame_tol) && isapprox(λ,42,atol=lame_tol)
		lame_correct = true
		correct()
	else
		lame_correct = false
		keep_working()
	end
end

# ╔═╡ d3c82d10-a372-11eb-36cf-4503372dbe21
if lame_correct === true
	material = Elasticity(λ,μ)
end

# ╔═╡ fab87028-a373-11eb-0bb2-ffda75bc703d
if lame_correct === true
	ν = (material.λ)/(2*((material.λ)+(material.μ)))
end

# ╔═╡ 85a629a9-bf53-4f09-a3d8-fd0dec621915
if lame_correct === true
	SymmetricTensor{2,3}([0.01, 0., 0., -0.01*ν, 0., -0.01*ν]) # SymmetricTensor{order, dimension}
end

# ╔═╡ b0b8f2de-46f7-4a2a-aed4-7d4eee920184
if lame_correct === true
	ε = [ SymmetricTensor{2,3}([e, 0., 0., -e*ν, 0., -e*ν]) for e in ε11 ];
end;

# ╔═╡ 6f6895e9-5db7-4526-b8a9-9d77bb6f38c1
begin
	α₁ = 100.
	α₂ = 150.
	α₃ = 50.
	a = Tensor{1,2}((1.,1.))
	
	if lame_correct == true
		transversal_material = TransversalIsotropic(λ,μ,α₁,α₂,α₃,a)
	else 
		transversal_material = TransversalIsotropic(1.,1.,α₁,α₂,α₃,a)
	end
end;

# ╔═╡ cdd8d34a-dc2d-4ef7-94e8-9ee0563da520
	σ_transversal = materialLaw(one(SymmetricTensor{2,2}),transversal_material)[1];

# ╔═╡ 875dac3c-a379-11eb-1e21-0729c4722597
if lame_correct == true
	if getindex.(materialLaw.(ε,(material,)),1)[1] == Missing
		material_status::Bool = false
		still_missing()
	elseif getindex.(materialLaw.(ε,(material,)),1) == [material.λ * tr(ϵ) * one(SymmetricTensor{2,3}) + 2*material.μ * ϵ for ϵ in ε]
		material_status::Bool = true
		correct()
	else
		material_status::Bool = false
		keep_working()
	end
else
	material_status::Bool = false
	still_missing()
end


# ╔═╡ 601b5240-a41a-11eb-236b-2f65c372d6fd
# if constitutive_driver(ε[1],material)[2] !== missing
if material_status == true
	tovoigt(materialLaw(ε[1],material)[2])
end

# ╔═╡ e0e2d32c-925c-4016-ae24-f1d78e1061bc
begin
	if material_status == true && lame_correct == true
		plot_material(ε, material)
	else
		fig = GLMakie.Figure()
		GLMakie.Label(fig[1,1],
			"In time, a plot will appear here!",
			color=:red,
			fontsize=30)
		fig
	end
end

# ╔═╡ c629d02d-8a27-42e4-aaa2-f491e6bbb0bc
if σ_transversal==Missing
	transversal_status::Bool = false
	still_missing()
elseif norm(σ_transversal)≈2246.544457605947
	transversal_status::Bool = true
	correct()
else
	transversal_status::Bool = false
	keep_working()
end

# ╔═╡ 9400898f-1462-47fd-95d2-a87db52a0dda
function create_dofhandler(grid::Grid{dim}, interpolation) where dim
    dh = DofHandler(grid)
    push!(dh, :u, dim, interpolation) # add a displacement field with 3 components
    close!(dh)
    return dh
end;

# ╔═╡ f7411d90-e24a-44ed-89c9-c0befaf73d4f
function create_bc(dh, dirichlets, grid)
    dbcs = ConstraintHandler(dh)
    for dirichlet in dirichlets
        add!(dbcs, dirichlet)
    end
    close!(dbcs)
    return dbcs
end;

# ╔═╡ 54501740-1190-4fc7-8904-06f71b6d45b1
function create_values(interpolation::Interpolation{dim, shape}) where {dim, shape}
    # setup quadrature rules
    qr      = QuadratureRule{dim,shape}(2)
    face_qr = QuadratureRule{dim-1,shape}(3)

    # cell and facevalues for u
    cellvalues_u = CellVectorValues(qr, interpolation)
    facevalues_u = FaceVectorValues(face_qr, interpolation)

    return cellvalues_u, facevalues_u
end;

# ╔═╡ 0c12c0f7-3e93-4616-a137-2dc24b1a0fba
function symmetrize_lower!(K)
    for i in 1:size(K,1)
        for j in i+1:size(K,1)
            K[i,j] = K[j,i]
        end
    end
end;

# ╔═╡ 9b3da86d-dcb5-4c5c-8fb8-716e2250367a
function assemble_cell!(Ke, re, cell, cellvalues, facevalues, grid,
                        ue, state, t)
    n_basefuncs = getnbasefunctions(cellvalues)
    reinit!(cellvalues, cell)

    for q_point in 1:getnquadpoints(cellvalues)
	# For each integration point, compute stress and material stiffness
        Gradu = function_gradient(cellvalues, q_point, ue)
        ϵ = symmetric(Gradu) # Total strain
	σ, D = constitutive_driver(ϵ, state[q_point])

        dΩ = getdetJdV(cellvalues, q_point)
        for i in 1:n_basefuncs
            δϵ = symmetric(shape_gradient(cellvalues, q_point, i))

            re[i] += (δϵ ⊡ σ) * dΩ # add internal force to residual
            for j in 1:i
                Δϵ = symmetric(shape_gradient(cellvalues, q_point, j))
                Ke[i, j] += δϵ ⊡ D ⊡ Δϵ * dΩ
            end
        end
    end
    symmetrize_lower!(Ke)
end;

# ╔═╡ dd3ba250-6000-41b1-923c-8d265753b1ba
function doassemble(cellvalues::CellVectorValues{dim},
                    facevalues::FaceVectorValues{dim}, K::SparseMatrixCSC, grid::Grid,
                    dh::DofHandler, u, states, t) where {dim}
    r = zeros(ndofs(dh))
    assembler = start_assemble(K, r)
    nu = getnbasefunctions(cellvalues)
    re = zeros(nu)     # element residual vector
    ke = zeros(nu, nu) # element tangent matrix

    for (cell, state) in zip(CellIterator(dh), states)
        fill!(ke, 0)
        fill!(re, 0)
        eldofs = celldofs(cell)
        ue = u[eldofs]
        assemble_cell!(ke, re, cell, cellvalues, facevalues, grid,
                       ue, state, t)
        assemble!(assembler, eldofs, re, ke)
    end
    return K, r
end;

# ╔═╡ 1130e100-a3ab-11eb-3aca-851eeeb201df
function solve(material)
    shapefunctions = Lagrange{2, RefTetrahedron, 1}()
    integration = QuadratureRule{2, RefTetrahedron}(2)
    elementvalues = CellVectorValues(integration, shapefunctions)
    integration_bound = QuadratureRule{1, RefTetrahedron}(2)
    boundvalues = FaceVectorValues(integration_bound, shapefunctions)

	grid = plate_hole()
	
    addfaceset!(grid,"top", x->norm(x[2]) ≈ 100.0)
    addfaceset!(grid,"bottom", x->norm(x[2]) ≈ 0.0)
    addfaceset!(grid,"left", x->norm(x[1]) ≈ 0.0)
    addfaceset!(grid,"right", x->norm(x[1]) ≈ 100.0)

	addfaceset!(grid,"leftMid", x-> norm(x[1]) ≈ 0.0 && isapprox(norm(x[2]), 50.0,atol=2.0))
	addfaceset!(grid,"botMid", x-> isapprox(norm(x[1]), 50.0, atol=2.0) && norm(x[2]) ≈ 0.0 )
	addfaceset!(grid,"topMid", x-> isapprox(norm(x[1]), 50.0, atol=2.0) && norm(x[2]) ≈ 100.0 )
    
    dh = DofHandler(grid)

    push!(dh, :u, 2)
    close!(dh)

	dirichletDisplacement=10
	
    ch = ConstraintHandler(dh)
    ∂Ω1 = getfaceset(grid, "left")
    dbc1 = Dirichlet(:u, ∂Ω1, (x, t) -> -dirichletDisplacement,1)
    add!(ch, dbc1)
    ∂Ω2 = getfaceset(grid, "bottom")
    dbc2 = Dirichlet(:u, ∂Ω2, (x, t) -> -dirichletDisplacement,2)
    add!(ch, dbc2)
	∂Ω2 = getfaceset(grid, "top")
    dbc2 = Dirichlet(:u, ∂Ω2, (x, t) -> dirichletDisplacement,2)
    add!(ch, dbc2)
	∂Ω2 = getfaceset(grid, "right")
    dbc2 = Dirichlet(:u, ∂Ω2, (x, t) -> dirichletDisplacement,1)
    add!(ch, dbc2)
    close!(ch)
    Ferrite.update!(ch, 0.0)

	u = zeros(ndofs(dh))
    
    K, f = doassemble(elementvalues, boundvalues, dh, material)

	if det(K) ≈ 0
		return u, dh
	end

    apply!(K, f, ch)
    u = K \ f
    return u, dh
end;

# ╔═╡ 79024e33-d6f9-4af6-b321-888947740e09
function update_state!(materialstate) end;

# ╔═╡ 1f4c0ac8-6bd2-4777-80d6-f1b8c155b620
function compute_stress(cellvalues::CellVectorValues{dim,T}, dh::DofHandler, u,material) where {dim,T}

    n = getnbasefunctions(cellvalues)
    cell_dofs = zeros(Int, n)
    nqp = getnquadpoints(cellvalues)

    # Allocate storage for the fluxes to store
    σ = [SymmetricTensor{2,dim,T}[] for _ in 1:getncells(dh.grid)]
    ϵ = [SymmetricTensor{2,dim,T}[] for _ in 1:getncells(dh.grid)]

    for (cell_num, cell) in enumerate(CellIterator(dh))
        σ_cell = σ[cell_num]
        ϵ_cell = ϵ[cell_num]
        celldofs!(cell_dofs, dh, cell_num)
        uᵉ = u[cell_dofs]
        reinit!(cellvalues, cell)

        for q_point in 1:nqp
            ϵ_qp = function_symmetric_gradient(cellvalues, q_point, uᵉ)
            push!(ϵ_cell, ϵ_qp)
            σ_qp, _ = constitutive_driver(ϵ_qp,material[cell_num][q_point])
            push!(σ_cell, σ_qp)
        end
    end
    return σ,ϵ
end;

# ╔═╡ 5cee667a-aba3-4be0-8f9f-2b35b15ed7e6
function solve(grid::Grid{dim}, dirichlets, material, args...; n_timesteps = 10, NEWTON_TOL=1e-8, kwargs...) where dim
    u_max = zeros(n_timesteps)
    max_magnitude = 1.7
    traction_magnitude = collect(max_magnitude/n_timesteps:max_magnitude/n_timesteps:max_magnitude)

    #grid = saved_file_to_grid("../definitions/quarter_plate.msh")
    #addfaceset!(grid,"top", x->norm(x[2]) ≈ 50.0)
    #addfaceset!(grid,"bottom", x->norm(x[2]) ≈ 0.0)
    #addfaceset!(grid,"left", x->norm(x[1]) ≈ 0.0)
    #addfaceset!(grid,"right", x->norm(x[1]) ≈ 50.0)
    #grid = generate_grid(Triangle,(100,100),Vec{2}((0.0,0.0)), Vec{2}((1.0,1.0)))
    interpolation = Ferrite.default_interpolation(getcelltype(grid))

    dh = create_dofhandler(grid, interpolation) # Ferrite helper function
    dbcs = create_bc(dh, dirichlets, grid) # create Dirichlet boundary-conditions

    cellvalues, facevalues = create_values(interpolation)

    # Pre-allocate solution vectors, etc.
    n_dofs = ndofs(dh)  # total number of dofs
    u  = zeros(n_dofs)  # solution vector
    Δu = zeros(n_dofs)  # displacement correction
    r = zeros(n_dofs)   # residual
    K = create_sparsity_pattern(dh); # tangent stiffness matrix

    # Create material states. One array for each cell, where each element is an array of material-
    # states - one for each integration point
    nqp = getnquadpoints(cellvalues)
    states = [[material(args...;kwargs...) for _ in 1:nqp] for _ in 1:getncells(grid)]
    σhistory =  []
    ϵhistory =  []
    uhistory = []
    statehistory = []
    # states = [MaterialState() for _ in 1:nqp for _ in 1:getncells(grid)]
    # temp_states = [MaterialState() for _ in 1:nqp for _ in 1:getncells(grid)]

    # Newton-Raphson loop
    for timestep in 1:n_timesteps
        t = timestep/n_timesteps # actual time (used for evaluating d-bndc)
        traction = Dict("left" => Vec((-traction_magnitude[timestep], 0.0)), "top" => Vec((0.0,traction_magnitude[timestep])))
        newton_itr = -1
        update!(dbcs, t) # evaluates the D-bndc at time t
        apply!(u, dbcs)  # set the prescribed values in the solution vector

        while true; newton_itr += 1
            if newton_itr > 10
                error("Reached maximum Newton iterations (n=$newton_itr), aborting")
                break
            end
            K, r = doassemble(cellvalues, facevalues, K, grid, dh, u,
                             states, traction);
            norm_r = norm(r[Ferrite.free_dofs(dbcs)])

            if norm_r < NEWTON_TOL
                break
            end

            apply_zero!(K, r, dbcs)
            Δu = Symmetric(K) \ r
            u -= Δu
            
            if norm(Δu) < NEWTON_TOL
                break
            end

        end
        
        # Update all the material states after we have reached equilibrium
        for cell_states in states
            foreach(update_state!, cell_states)
        end
        
        push!(uhistory, u)
        #u_max[timestep] = max(abs.(u)...) # maximum displacement in current timestep
        σ,ϵ = compute_stress(cellvalues,dh,u,states)
        push!(σhistory,sum.(σ) ./ length(σ[1]))
        push!(ϵhistory,sum.(ϵ) ./ length(ϵ[1]))
        push!(statehistory,deepcopy(states))

    end

    return u, dh, σhistory, ϵhistory, uhistory, statehistory
end;

# ╔═╡ af8f8762-59a2-4a77-8bb5-1a1d9a68d742
if material_status == true
	u, dh = solve(material)
	if isapprox(norm(u), 1047.7860415034465,atol=lame_tol)
		assemble_implemented = true
	else
		assemble_implemented = false
	end
else
	assemble_implemented = false
end;

# ╔═╡ c7cd5338-a419-11eb-3e8c-e9e35e50a93a
if lame_correct == true && material_status == true && assemble_implemented == true
	correct()
elseif material_status == false
	still_missing(
		md"First you have to implement the material law `materialLaw()` correctly, before you adjust the assembley function.")
else
	still_missing(md"Add a call to the material model at the right place!")
end

# ╔═╡ 5a4e9672-5cde-4763-bfba-94981d4556b3
if assemble_implemented == true
	@bind plot_comp Select(["norm(u)", "u₁", "u₂"])
end

# ╔═╡ 94d173d7-182b-4f97-9969-70427d51aa92
if assemble_implemented == true
	@bind deformation_scale Slider(1:5;default=2,show_value=true)
end

# ╔═╡ ff2bfdbd-1780-4cb2-b560-01909be25888
if assemble_implemented == true
	if plot_comp == "norm(u)"
		the_process_el = x -> norm(x)
	elseif plot_comp == "u₁"
		the_process_el = x -> x[1]
	elseif plot_comp == "u₂"
		the_process_el = x -> x[2]
	end
	
	the_title_el = "Solution for the linear elastic material model: " * plot_comp
	
	fig_el = GLMakie.Figure()
	axis_el = GLMakie.Axis(fig_el[1,1],
		title=the_title_el,
		xlabel="x₁-Direction",
		ylabel="x₂-Direction",aspect=1)
	
	plotter = MakiePlotter(dh,u);
	plot_el = solutionplot!(axis_el, plotter;
		deformation_field=:u,
		deformation_scale,
		process=the_process_el)
	
	GLMakie.Colorbar(fig_el[1,2], plot_el)
	
	fig_el
end

# ╔═╡ 8fa4d7ad-032f-40a8-b4e0-fcc2e41ac0ef
if assemble_implemented == true && transversal_status == true
	md"""
	The deformation is different with fibers in the [1,1] direction. Because of increased stiffness in this direction, it is more difficult to increase the distance between two points. This results in a deformation profile as shown below to appear.
	"""
end

# ╔═╡ 41e4ec16-6bc4-40b9-a793-0b4ed74bed0f
if assemble_implemented == true && transversal_status == true
	@bind transversal_plot_comp Select(["norm(u)", "u₁", "u₂"])
end

# ╔═╡ ed01158c-ad86-4ff0-92ba-801a80f8fd07
if assemble_implemented == true && transversal_status == true
	if transversal_plot_comp == "u₁"
		the_process = x -> x[1]
	elseif transversal_plot_comp == "u₂"
		the_process = x -> x[2]
	elseif transversal_plot_comp == "norm(u)"
		the_process = x -> norm(x)
	else
		@error "Something went wrong here!1!!"
	end

	the_title = "Plot of " * transversal_plot_comp

	fig_tr = GLMakie.Figure()
	axis_tr = GLMakie.Axis(fig_tr[1,1], 
		title=the_title,
		xlabel = "x₁-Direction",
		ylabel = "x₂-Direction",aspect=1)
	
	u_transversal, dh_transversal = solve(transversal_material);
	
	plotter_transversal = MakiePlotter(dh_transversal, u_transversal);
	
	 transversal_plot = solutionplot!(axis_tr, plotter_transversal;
		deformation_field=:u,
		deformation_scale,
		process = the_process
	)

	GLMakie.Colorbar(fig_tr[1,2], transversal_plot)

	fig_tr
elseif assemble_implemented == false || transversal_status == false
	still_missing(
		md"Once you get FEM up and running and you have implemented the transversal-isotropic material model, you will see here the solution here!.",
		"Not yet!")
	
end

# ╔═╡ 00000000-0000-0000-0000-000000000001
PLUTO_PROJECT_TOML_CONTENTS = """
[deps]
Ferrite = "c061ca5d-56c9-439f-9c0e-210fe06d3992"
FerriteGmsh = "4f95f4f8-b27c-4ae5-9a39-ea55e634e36b"
FerriteViz = "59d0093e-b1f1-4fb7-ac85-ab57e45f39d9"
GLMakie = "e9467ef8-e4e7-5192-8a1a-b1aee30e663a"
PlutoUI = "7f904dfe-b85e-4ff6-b463-dae2292396a8"
SparseArrays = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"
Tensors = "48a634ad-e948-5137-8d70-aa71f2a747f4"

[compat]
Ferrite = "~0.3.8"
FerriteGmsh = "~1.0.0"
FerriteViz = "~0.2.0"
GLMakie = "~0.8.12"
PlutoUI = "~0.7.44"
Tensors = "~1.13.1"
"""

# ╔═╡ 00000000-0000-0000-0000-000000000002
PLUTO_MANIFEST_TOML_CONTENTS = """
# This file is machine-generated - editing it directly is not advised

julia_version = "1.11.1"
manifest_format = "2.0"
project_hash = "dc828151ccacfaf80ccce068ccc00f27ad6a89c7"

[[deps.AbstractFFTs]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "d92ad398961a3ed262d8bf04a1a2b8340f915fef"
uuid = "621f4979-c628-5d54-868e-fcf4e3e8185c"
version = "1.5.0"
weakdeps = ["ChainRulesCore", "Test"]

    [deps.AbstractFFTs.extensions]
    AbstractFFTsChainRulesCoreExt = "ChainRulesCore"
    AbstractFFTsTestExt = "Test"

[[deps.AbstractLattices]]
git-tree-sha1 = "763b6f3f6bfabd72c7e262cbb5ddfd43fd5c6398"
uuid = "398f06c4-4d28-53ec-89ca-5b2656b7603d"
version = "0.3.1"

[[deps.AbstractPlutoDingetjes]]
deps = ["Pkg"]
git-tree-sha1 = "6e1d2a35f2f90a4bc7c2ed98079b2ba09c35b83a"
uuid = "6e696c72-6542-2067-7265-42206c756150"
version = "1.3.2"

[[deps.AbstractTrees]]
git-tree-sha1 = "03e0550477d86222521d254b741d470ba17ea0b5"
uuid = "1520ce14-60c1-5f80-bbc7-55ef81b5835c"
version = "0.3.4"

[[deps.Adapt]]
deps = ["LinearAlgebra", "Requires"]
git-tree-sha1 = "50c3c56a52972d78e8be9fd135bfb91c9574c140"
uuid = "79e6a3ab-5dfb-504d-930d-738a2a938a0e"
version = "4.1.1"
weakdeps = ["StaticArrays"]

    [deps.Adapt.extensions]
    AdaptStaticArraysExt = "StaticArrays"

[[deps.AliasTables]]
deps = ["PtrArrays", "Random"]
git-tree-sha1 = "9876e1e164b144ca45e9e3198d0b689cadfed9ff"
uuid = "66dad0bd-aa9a-41b7-9441-69ab47430ed8"
version = "1.1.3"

[[deps.Animations]]
deps = ["Colors"]
git-tree-sha1 = "e81c509d2c8e49592413bfb0bb3b08150056c79d"
uuid = "27a7e980-b3e6-11e9-2bcd-0b925532e340"
version = "0.4.1"

[[deps.ArgTools]]
uuid = "0dad84c5-d112-42e6-8d28-ef12dabb789f"
version = "1.1.2"

[[deps.ArrayInterface]]
deps = ["Adapt", "LinearAlgebra"]
git-tree-sha1 = "3640d077b6dafd64ceb8fd5c1ec76f7ca53bcf76"
uuid = "4fba245c-0d91-5ea0-9b3e-6abc04ee57a9"
version = "7.16.0"

    [deps.ArrayInterface.extensions]
    ArrayInterfaceBandedMatricesExt = "BandedMatrices"
    ArrayInterfaceBlockBandedMatricesExt = "BlockBandedMatrices"
    ArrayInterfaceCUDAExt = "CUDA"
    ArrayInterfaceCUDSSExt = "CUDSS"
    ArrayInterfaceChainRulesExt = "ChainRules"
    ArrayInterfaceGPUArraysCoreExt = "GPUArraysCore"
    ArrayInterfaceReverseDiffExt = "ReverseDiff"
    ArrayInterfaceSparseArraysExt = "SparseArrays"
    ArrayInterfaceStaticArraysCoreExt = "StaticArraysCore"
    ArrayInterfaceTrackerExt = "Tracker"

    [deps.ArrayInterface.weakdeps]
    BandedMatrices = "aae01518-5342-5314-be14-df237901396f"
    BlockBandedMatrices = "ffab5731-97b5-5995-9138-79e8c1846df0"
    CUDA = "052768ef-5323-5732-b1bb-66c8b64840ba"
    CUDSS = "45b445bb-4962-46a0-9369-b4df9d0f772e"
    ChainRules = "082447d4-558c-5d27-93f4-14fc19e9eca2"
    GPUArraysCore = "46192b85-c4d5-4398-a991-12ede77f4527"
    ReverseDiff = "37e2e3b7-166d-5795-8a7a-e32c996b4267"
    SparseArrays = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"
    StaticArraysCore = "1e83bf80-4336-4d27-bf5d-d5a4f845583c"
    Tracker = "9f7883ad-71c0-57eb-9f7f-b5c9e6d3789c"

[[deps.Artifacts]]
uuid = "56f22d72-fd6d-98f1-02f0-08ddc0907c33"
version = "1.11.0"

[[deps.Automa]]
deps = ["PrecompileTools", "SIMD", "TranscodingStreams"]
git-tree-sha1 = "a8f503e8e1a5f583fbef15a8440c8c7e32185df2"
uuid = "67c07d97-cdcb-5c2c-af73-a7f9c32a568b"
version = "1.1.0"

[[deps.AxisAlgorithms]]
deps = ["LinearAlgebra", "Random", "SparseArrays", "WoodburyMatrices"]
git-tree-sha1 = "01b8ccb13d68535d73d2b0c23e39bd23155fb712"
uuid = "13072b0f-2c55-5437-9ae7-d433b7a33950"
version = "1.1.0"

[[deps.AxisArrays]]
deps = ["Dates", "IntervalSets", "IterTools", "RangeArrays"]
git-tree-sha1 = "16351be62963a67ac4083f748fdb3cca58bfd52f"
uuid = "39de3d68-74b9-583c-8d2d-e117c070f3a9"
version = "0.4.7"

[[deps.Base64]]
uuid = "2a0f44e3-6c83-55bd-87e4-b1978d98bd5f"
version = "1.11.0"

[[deps.Bzip2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "8873e196c2eb87962a2048b3b8e08946535864a1"
uuid = "6e34b625-4abd-537c-b88f-471c36dfa7a0"
version = "1.0.8+2"

[[deps.CEnum]]
git-tree-sha1 = "389ad5c84de1ae7cf0e28e381131c98ea87d54fc"
uuid = "fa961155-64e5-5f13-b03f-caf6b980ea82"
version = "0.5.0"

[[deps.CRC32c]]
uuid = "8bf52ea8-c179-5cab-976a-9e18b702a9bc"
version = "1.11.0"

[[deps.CRlibm_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "e329286945d0cfc04456972ea732551869af1cfc"
uuid = "4e9b3aee-d8a1-5a3d-ad8b-7d824db253f0"
version = "1.0.1+0"

[[deps.Cairo_jll]]
deps = ["Artifacts", "Bzip2_jll", "CompilerSupportLibraries_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "JLLWrappers", "LZO_jll", "Libdl", "Pixman_jll", "Xorg_libXext_jll", "Xorg_libXrender_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "009060c9a6168704143100f36ab08f06c2af4642"
uuid = "83423d85-b0ee-5818-9007-b63ccbeb887a"
version = "1.18.2+1"

[[deps.ChainRulesCore]]
deps = ["Compat", "LinearAlgebra"]
git-tree-sha1 = "3e4b134270b372f2ed4d4d0e936aabaefc1802bc"
uuid = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
version = "1.25.0"
weakdeps = ["SparseArrays"]

    [deps.ChainRulesCore.extensions]
    ChainRulesCoreSparseArraysExt = "SparseArrays"

[[deps.CodecZlib]]
deps = ["TranscodingStreams", "Zlib_jll"]
git-tree-sha1 = "bce6804e5e6044c6daab27bb533d1295e4a2e759"
uuid = "944b1d66-785c-5afd-91f1-9de20f533193"
version = "0.7.6"

[[deps.ColorBrewer]]
deps = ["Colors", "JSON", "Test"]
git-tree-sha1 = "61c5334f33d91e570e1d0c3eb5465835242582c4"
uuid = "a2cac450-b92f-5266-8821-25eda20663c8"
version = "0.4.0"

[[deps.ColorSchemes]]
deps = ["ColorTypes", "ColorVectorSpace", "Colors", "FixedPointNumbers", "PrecompileTools", "Random"]
git-tree-sha1 = "b5278586822443594ff615963b0c09755771b3e0"
uuid = "35d6a980-a343-548e-a6ea-1d62b119f2f4"
version = "3.26.0"

[[deps.ColorTypes]]
deps = ["FixedPointNumbers", "Random"]
git-tree-sha1 = "b10d0b65641d57b8b4d5e234446582de5047050d"
uuid = "3da002f7-5984-5a60-b8a6-cbb66c0b333f"
version = "0.11.5"

[[deps.ColorVectorSpace]]
deps = ["ColorTypes", "FixedPointNumbers", "LinearAlgebra", "SpecialFunctions", "Statistics", "TensorCore"]
git-tree-sha1 = "600cc5508d66b78aae350f7accdb58763ac18589"
uuid = "c3611d14-8923-5661-9e6a-0046d554d3a4"
version = "0.9.10"

[[deps.Colors]]
deps = ["ColorTypes", "FixedPointNumbers", "Reexport"]
git-tree-sha1 = "362a287c3aa50601b0bc359053d5c2468f0e7ce0"
uuid = "5ae59095-9a9b-59fe-a467-6f913c188581"
version = "0.12.11"

[[deps.Combinatorics]]
git-tree-sha1 = "08c8b6831dc00bfea825826be0bc8336fc369860"
uuid = "861a8166-3701-5b0c-9a16-15d98fcdc6aa"
version = "1.0.2"

[[deps.CommonSubexpressions]]
deps = ["MacroTools"]
git-tree-sha1 = "cda2cfaebb4be89c9084adaca7dd7333369715c5"
uuid = "bbf7d656-a473-5ed7-a52c-81e309532950"
version = "0.3.1"

[[deps.Compat]]
deps = ["TOML", "UUIDs"]
git-tree-sha1 = "8ae8d32e09f0dcf42a36b90d4e17f5dd2e4c4215"
uuid = "34da2185-b29b-5c13-b0c7-acf172513d20"
version = "4.16.0"
weakdeps = ["Dates", "LinearAlgebra"]

    [deps.Compat.extensions]
    CompatLinearAlgebraExt = "LinearAlgebra"

[[deps.CompilerSupportLibraries_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "e66e0078-7015-5450-92f7-15fbd957f2ae"
version = "1.1.1+0"

[[deps.ConstructionBase]]
git-tree-sha1 = "76219f1ed5771adbb096743bff43fb5fdd4c1157"
uuid = "187b0558-2788-49d3-abe0-74a17ed4e7c9"
version = "1.5.8"
weakdeps = ["IntervalSets", "LinearAlgebra", "StaticArrays"]

    [deps.ConstructionBase.extensions]
    ConstructionBaseIntervalSetsExt = "IntervalSets"
    ConstructionBaseLinearAlgebraExt = "LinearAlgebra"
    ConstructionBaseStaticArraysExt = "StaticArrays"

[[deps.Contour]]
git-tree-sha1 = "439e35b0b36e2e5881738abc8857bd92ad6ff9a8"
uuid = "d38c429a-6771-53c6-b99e-75d170b6e991"
version = "0.6.3"

[[deps.DataAPI]]
git-tree-sha1 = "abe83f3a2f1b857aac70ef8b269080af17764bbe"
uuid = "9a962f9c-6df0-11e9-0e5d-c546b8b5ee8a"
version = "1.16.0"

[[deps.DataStructures]]
deps = ["Compat", "InteractiveUtils", "OrderedCollections"]
git-tree-sha1 = "1d0a14036acb104d9e89698bd408f63ab58cdc82"
uuid = "864edb3b-99cc-5e75-8d2d-829cb0a9cfe8"
version = "0.18.20"

[[deps.DataValueInterfaces]]
git-tree-sha1 = "bfc1187b79289637fa0ef6d4436ebdfe6905cbd6"
uuid = "e2d170a0-9d28-54be-80f0-106bbe20a464"
version = "1.0.0"

[[deps.Dates]]
deps = ["Printf"]
uuid = "ade2ca70-3891-5945-98fb-dc099432e06a"
version = "1.11.0"

[[deps.Dbus_jll]]
deps = ["Artifacts", "Expat_jll", "JLLWrappers", "Libdl"]
git-tree-sha1 = "fc173b380865f70627d7dd1190dc2fce6cc105af"
uuid = "ee1fde0b-3d02-5ea6-8484-8dfef6360eab"
version = "1.14.10+0"

[[deps.DelaunayTriangulation]]
deps = ["DataStructures", "EnumX", "ExactPredicates", "Random", "SimpleGraphs"]
git-tree-sha1 = "d4e9dc4c6106b8d44e40cd4faf8261a678552c7c"
uuid = "927a84f5-c5f4-47a5-9785-b46e178433df"
version = "0.8.12"

[[deps.DiffResults]]
deps = ["StaticArraysCore"]
git-tree-sha1 = "782dd5f4561f5d267313f23853baaaa4c52ea621"
uuid = "163ba53b-c6d8-5494-b064-1a9d43ac40c5"
version = "1.1.0"

[[deps.DiffRules]]
deps = ["IrrationalConstants", "LogExpFunctions", "NaNMath", "Random", "SpecialFunctions"]
git-tree-sha1 = "23163d55f885173722d1e4cf0f6110cdbaf7e272"
uuid = "b552c78f-8df3-52c6-915a-8e097449b14b"
version = "1.15.1"

[[deps.Distances]]
deps = ["LinearAlgebra", "Statistics", "StatsAPI"]
git-tree-sha1 = "c7e3a542b999843086e2f29dac96a618c105be1d"
uuid = "b4f34e82-e78d-54a5-968a-f98e89d6e8f7"
version = "0.10.12"
weakdeps = ["ChainRulesCore", "SparseArrays"]

    [deps.Distances.extensions]
    DistancesChainRulesCoreExt = "ChainRulesCore"
    DistancesSparseArraysExt = "SparseArrays"

[[deps.Distributed]]
deps = ["Random", "Serialization", "Sockets"]
uuid = "8ba89e20-285c-5b6f-9357-94700520ee1b"
version = "1.11.0"

[[deps.Distributions]]
deps = ["AliasTables", "FillArrays", "LinearAlgebra", "PDMats", "Printf", "QuadGK", "Random", "SpecialFunctions", "Statistics", "StatsAPI", "StatsBase", "StatsFuns"]
git-tree-sha1 = "3101c32aab536e7a27b1763c0797dba151b899ad"
uuid = "31c24e10-a181-5473-b8eb-7969acd0382f"
version = "0.25.113"

    [deps.Distributions.extensions]
    DistributionsChainRulesCoreExt = "ChainRulesCore"
    DistributionsDensityInterfaceExt = "DensityInterface"
    DistributionsTestExt = "Test"

    [deps.Distributions.weakdeps]
    ChainRulesCore = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
    DensityInterface = "b429d917-457f-4dbc-8f4c-0cc954292b1d"
    Test = "8dfed614-e22c-5e08-85e1-65c5234f0b40"

[[deps.DocStringExtensions]]
deps = ["LibGit2"]
git-tree-sha1 = "2fb1e02f2b635d0845df5d7c167fec4dd739b00d"
uuid = "ffbed154-4ef7-542d-bbb7-c09d3a79fcae"
version = "0.9.3"

[[deps.Downloads]]
deps = ["ArgTools", "FileWatching", "LibCURL", "NetworkOptions"]
uuid = "f43a241f-c20a-4ad4-852c-f6b1247861c6"
version = "1.6.0"

[[deps.EarCut_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "e3290f2d49e661fbd94046d7e3726ffcb2d41053"
uuid = "5ae413db-bbd1-5e63-b57d-d24a61df00f5"
version = "2.2.4+0"

[[deps.EnumX]]
git-tree-sha1 = "bdb1942cd4c45e3c678fd11569d5cccd80976237"
uuid = "4e289a0a-7415-4d19-859d-a7e5c4648b56"
version = "1.0.4"

[[deps.EpollShim_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "8e9441ee83492030ace98f9789a654a6d0b1f643"
uuid = "2702e6a9-849d-5ed8-8c21-79e8b8f9ee43"
version = "0.0.20230411+0"

[[deps.ExactPredicates]]
deps = ["IntervalArithmetic", "Random", "StaticArrays"]
git-tree-sha1 = "b3f2ff58735b5f024c392fde763f29b057e4b025"
uuid = "429591f6-91af-11e9-00e2-59fbe8cec110"
version = "2.2.8"

[[deps.Expat_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "1c6317308b9dc757616f0b5cb379db10494443a7"
uuid = "2e619515-83b5-522b-bb60-26c02a35a201"
version = "2.6.2+0"

[[deps.Extents]]
git-tree-sha1 = "81023caa0021a41712685887db1fc03db26f41f5"
uuid = "411431e0-e8b7-467b-b5e0-f676ba4f2910"
version = "0.1.4"

[[deps.FFMPEG_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "JLLWrappers", "LAME_jll", "Libdl", "Ogg_jll", "OpenSSL_jll", "Opus_jll", "PCRE2_jll", "Pkg", "Zlib_jll", "libaom_jll", "libass_jll", "libfdk_aac_jll", "libvorbis_jll", "x264_jll", "x265_jll"]
git-tree-sha1 = "74faea50c1d007c85837327f6775bea60b5492dd"
uuid = "b22a6f82-2f65-5046-a5b2-351ab43fb4e5"
version = "4.4.2+2"

[[deps.FFTW]]
deps = ["AbstractFFTs", "FFTW_jll", "LinearAlgebra", "MKL_jll", "Preferences", "Reexport"]
git-tree-sha1 = "4820348781ae578893311153d69049a93d05f39d"
uuid = "7a1cc6ca-52ef-59f5-83cd-3a7055c09341"
version = "1.8.0"

[[deps.FFTW_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4d81ed14783ec49ce9f2e168208a12ce1815aa25"
uuid = "f5851436-0d7a-5f13-b9de-f02708fd171a"
version = "3.3.10+1"

[[deps.FLTK_jll]]
deps = ["Artifacts", "Fontconfig_jll", "FreeType2_jll", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Libglvnd_jll", "Pkg", "Xorg_libX11_jll", "Xorg_libXext_jll", "Xorg_libXfixes_jll", "Xorg_libXft_jll", "Xorg_libXinerama_jll", "Xorg_libXrender_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "72a4842f93e734f378cf381dae2ca4542f019d23"
uuid = "4fce6fc7-ba6a-5f4c-898f-77e99806d6f8"
version = "1.3.8+0"

[[deps.Ferrite]]
deps = ["EnumX", "LinearAlgebra", "NearestNeighbors", "Preferences", "Reexport", "SparseArrays", "Tensors", "WriteVTK"]
git-tree-sha1 = "a31b9d4dd58e00686e5da175dab11667af3108b6"
uuid = "c061ca5d-56c9-439f-9c0e-210fe06d3992"
version = "0.3.14"

    [deps.Ferrite.extensions]
    FerriteBlockArrays = "BlockArrays"
    FerriteMetis = "Metis"

    [deps.Ferrite.weakdeps]
    BlockArrays = "8e7c35d0-a365-5155-bbbb-fb81a777f24e"
    Metis = "2679e427-3c69-5b7f-982b-ece356f1e94b"

[[deps.FerriteGmsh]]
deps = ["Ferrite", "Gmsh"]
git-tree-sha1 = "702427f9f6b2d3e39da3bfab4eea7d02f459e404"
uuid = "4f95f4f8-b27c-4ae5-9a39-ea55e634e36b"
version = "1.0.1"

[[deps.FerriteViz]]
deps = ["Ferrite", "GeometryBasics", "LinearAlgebra", "Makie", "ShaderAbstractions", "Tensors"]
git-tree-sha1 = "4277f6a13ef32d1751e1354843bde862dc51a508"
uuid = "59d0093e-b1f1-4fb7-ac85-ab57e45f39d9"
version = "0.2.2"

[[deps.FileIO]]
deps = ["Pkg", "Requires", "UUIDs"]
git-tree-sha1 = "62ca0547a14c57e98154423419d8a342dca75ca9"
uuid = "5789e2e9-d7fb-5bc7-8068-2c6fae9b9549"
version = "1.16.4"

[[deps.FileWatching]]
uuid = "7b1f6079-737a-58dc-b8bc-7a2ca5c1b5ee"
version = "1.11.0"

[[deps.FillArrays]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "6a70198746448456524cb442b8af316927ff3e1a"
uuid = "1a297f60-69ca-5386-bcde-b61e274b549b"
version = "1.13.0"
weakdeps = ["PDMats", "SparseArrays", "Statistics"]

    [deps.FillArrays.extensions]
    FillArraysPDMatsExt = "PDMats"
    FillArraysSparseArraysExt = "SparseArrays"
    FillArraysStatisticsExt = "Statistics"

[[deps.FiniteDiff]]
deps = ["ArrayInterface", "LinearAlgebra", "Setfield"]
git-tree-sha1 = "b10bdafd1647f57ace3885143936749d61638c3b"
uuid = "6a86dc24-6348-571c-b903-95158fe2bd41"
version = "2.26.0"

    [deps.FiniteDiff.extensions]
    FiniteDiffBandedMatricesExt = "BandedMatrices"
    FiniteDiffBlockBandedMatricesExt = "BlockBandedMatrices"
    FiniteDiffSparseArraysExt = "SparseArrays"
    FiniteDiffStaticArraysExt = "StaticArrays"

    [deps.FiniteDiff.weakdeps]
    BandedMatrices = "aae01518-5342-5314-be14-df237901396f"
    BlockBandedMatrices = "ffab5731-97b5-5995-9138-79e8c1846df0"
    SparseArrays = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"
    StaticArrays = "90137ffa-7385-5640-81b9-e52037218182"

[[deps.FixedPointNumbers]]
deps = ["Statistics"]
git-tree-sha1 = "05882d6995ae5c12bb5f36dd2ed3f61c98cbb172"
uuid = "53c48c17-4a7d-5ca2-90c5-79b7896eea93"
version = "0.8.5"

[[deps.Fontconfig_jll]]
deps = ["Artifacts", "Bzip2_jll", "Expat_jll", "FreeType2_jll", "JLLWrappers", "Libdl", "Libuuid_jll", "Zlib_jll"]
git-tree-sha1 = "db16beca600632c95fc8aca29890d83788dd8b23"
uuid = "a3f928ae-7b40-5064-980b-68af3947d34b"
version = "2.13.96+0"

[[deps.Formatting]]
deps = ["Logging", "Printf"]
git-tree-sha1 = "fb409abab2caf118986fc597ba84b50cbaf00b87"
uuid = "59287772-0a20-5a39-b81b-1366585eb4c0"
version = "0.4.3"

[[deps.ForwardDiff]]
deps = ["CommonSubexpressions", "DiffResults", "DiffRules", "LinearAlgebra", "LogExpFunctions", "NaNMath", "Preferences", "Printf", "Random", "SpecialFunctions"]
git-tree-sha1 = "a9ce73d3c827adab2d70bf168aaece8cce196898"
uuid = "f6369f11-7733-5829-9624-2563aa707210"
version = "0.10.37"
weakdeps = ["StaticArrays"]

    [deps.ForwardDiff.extensions]
    ForwardDiffStaticArraysExt = "StaticArrays"

[[deps.FreeType]]
deps = ["CEnum", "FreeType2_jll"]
git-tree-sha1 = "907369da0f8e80728ab49c1c7e09327bf0d6d999"
uuid = "b38be410-82b0-50bf-ab77-7b57e271db43"
version = "4.1.1"

[[deps.FreeType2_jll]]
deps = ["Artifacts", "Bzip2_jll", "JLLWrappers", "Libdl", "Zlib_jll"]
git-tree-sha1 = "5c1d8ae0efc6c2e7b1fc502cbe25def8f661b7bc"
uuid = "d7e528f0-a631-5988-bf34-fe36492bcfd7"
version = "2.13.2+0"

[[deps.FreeTypeAbstraction]]
deps = ["ColorVectorSpace", "Colors", "FreeType", "GeometryBasics"]
git-tree-sha1 = "84dfe824bd6fdf2a5d73bb187ff31b5549b2a79c"
uuid = "663a7486-cb36-511b-a19d-713bb74d65c9"
version = "0.10.4"

[[deps.FriBidi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "1ed150b39aebcc805c26b93a8d0122c940f64ce2"
uuid = "559328eb-81f9-559d-9380-de523a88c83c"
version = "1.0.14+0"

[[deps.Future]]
deps = ["Random"]
uuid = "9fa8497b-333b-5362-9e8d-4d0656e87820"
version = "1.11.0"

[[deps.GLFW]]
deps = ["GLFW_jll"]
git-tree-sha1 = "7ed24cfc4cb29fb10c0e8cca871ddff54c32a4c3"
uuid = "f7f18e0c-5ee9-5ccd-a5bf-e8befd85ed98"
version = "3.4.3"

[[deps.GLFW_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libglvnd_jll", "Xorg_libXcursor_jll", "Xorg_libXi_jll", "Xorg_libXinerama_jll", "Xorg_libXrandr_jll", "libdecor_jll", "xkbcommon_jll"]
git-tree-sha1 = "532f9126ad901533af1d4f5c198867227a7bb077"
uuid = "0656b61e-2033-5cc2-a64a-77c0f6c09b89"
version = "3.4.0+1"

[[deps.GLMakie]]
deps = ["ColorTypes", "Colors", "FileIO", "FixedPointNumbers", "FreeTypeAbstraction", "GLFW", "GeometryBasics", "LinearAlgebra", "Makie", "Markdown", "MeshIO", "ModernGL", "Observables", "PrecompileTools", "Printf", "ShaderAbstractions", "StaticArrays"]
git-tree-sha1 = "8236ce4eda9837d15bab49573bba16ba0652b486"
uuid = "e9467ef8-e4e7-5192-8a1a-b1aee30e663a"
version = "0.8.12"

[[deps.GLU_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libglvnd_jll", "Pkg"]
git-tree-sha1 = "65af046f4221e27fb79b28b6ca89dd1d12bc5ec7"
uuid = "bd17208b-e95e-5925-bf81-e2f59b3e5c61"
version = "9.0.1+0"

[[deps.GMP_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "781609d7-10c4-51f6-84f2-b8444358ff6d"
version = "6.3.0+0"

[[deps.GeoFormatTypes]]
git-tree-sha1 = "59107c179a586f0fe667024c5eb7033e81333271"
uuid = "68eda718-8dee-11e9-39e7-89f7f65f511f"
version = "0.4.2"

[[deps.GeoInterface]]
deps = ["Extents", "GeoFormatTypes"]
git-tree-sha1 = "826b4fd69438d9ce4d2b19de6bc2f970f45f0f88"
uuid = "cf35fbd7-0cd7-5166-be24-54bfbe79505f"
version = "1.3.8"

[[deps.GeometryBasics]]
deps = ["EarCut_jll", "Extents", "GeoInterface", "IterTools", "LinearAlgebra", "StaticArrays", "StructArrays", "Tables"]
git-tree-sha1 = "b62f2b2d76cee0d61a2ef2b3118cd2a3215d3134"
uuid = "5c1252a2-5f33-56bf-86c9-59e7332b4326"
version = "0.4.11"

[[deps.Gettext_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "9b02998aba7bf074d14de89f9d37ca24a1a0b046"
uuid = "78b55507-aeef-58d4-861c-77aaff3498b1"
version = "0.21.0+0"

[[deps.Glib_jll]]
deps = ["Artifacts", "Gettext_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Libiconv_jll", "Libmount_jll", "PCRE2_jll", "Zlib_jll"]
git-tree-sha1 = "674ff0db93fffcd11a3573986e550d66cd4fd71f"
uuid = "7746bdde-850d-59dc-9ae8-88ece973131d"
version = "2.80.5+0"

[[deps.Gmsh]]
deps = ["gmsh_jll"]
git-tree-sha1 = "4d4dedef84147934837c683538467cea54c44d44"
uuid = "705231aa-382f-11e9-3f0c-b7cb4346fdeb"
version = "0.2.2"

[[deps.Graphics]]
deps = ["Colors", "LinearAlgebra", "NaNMath"]
git-tree-sha1 = "d61890399bc535850c4bf08e4e0d3a7ad0f21cbd"
uuid = "a2bd30eb-e257-5431-a919-1863eab51364"
version = "1.1.2"

[[deps.Graphite2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "344bf40dcab1073aca04aa0df4fb092f920e4011"
uuid = "3b182d85-2403-5c21-9c21-1e1f0cc25472"
version = "1.3.14+0"

[[deps.GridLayoutBase]]
deps = ["GeometryBasics", "InteractiveUtils", "Observables"]
git-tree-sha1 = "f57a64794b336d4990d90f80b147474b869b1bc4"
uuid = "3955a311-db13-416c-9275-1d80ed98e5e9"
version = "0.9.2"

[[deps.Grisu]]
git-tree-sha1 = "53bb909d1151e57e2484c3d1b53e19552b887fb2"
uuid = "42e2da0e-8278-4e71-bc24-59509adca0fe"
version = "1.0.2"

[[deps.HDF5_jll]]
deps = ["Artifacts", "JLLWrappers", "LibCURL_jll", "Libdl", "OpenSSL_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "4cc2bb72df6ff40b055295fdef6d92955f9dede8"
uuid = "0234f1f7-429e-5d53-9886-15a909be8d59"
version = "1.12.2+2"

[[deps.HarfBuzz_jll]]
deps = ["Artifacts", "Cairo_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "Graphite2_jll", "JLLWrappers", "Libdl", "Libffi_jll"]
git-tree-sha1 = "401e4f3f30f43af2c8478fc008da50096ea5240f"
uuid = "2e76f6c2-a576-52d4-95c1-20adfe4de566"
version = "8.3.1+0"

[[deps.HypergeometricFunctions]]
deps = ["LinearAlgebra", "OpenLibm_jll", "SpecialFunctions"]
git-tree-sha1 = "7c4195be1649ae622304031ed46a2f4df989f1eb"
uuid = "34004b35-14d8-5ef3-9330-4cdb6864b03a"
version = "0.3.24"

[[deps.Hyperscript]]
deps = ["Test"]
git-tree-sha1 = "8d511d5b81240fc8e6802386302675bdf47737b9"
uuid = "47d2ed2b-36de-50cf-bf87-49c2cf4b8b91"
version = "0.0.4"

[[deps.HypertextLiteral]]
deps = ["Tricks"]
git-tree-sha1 = "7134810b1afce04bbc1045ca1985fbe81ce17653"
uuid = "ac1192a8-f4b3-4bfe-ba22-af5b92cd3ab2"
version = "0.9.5"

[[deps.IOCapture]]
deps = ["Logging", "Random"]
git-tree-sha1 = "b6d6bfdd7ce25b0f9b2f6b3dd56b2673a66c8770"
uuid = "b5f81e59-6552-4d32-b1f0-c071b021bf89"
version = "0.2.5"

[[deps.ImageAxes]]
deps = ["AxisArrays", "ImageBase", "ImageCore", "Reexport", "SimpleTraits"]
git-tree-sha1 = "2e4520d67b0cef90865b3ef727594d2a58e0e1f8"
uuid = "2803e5a7-5153-5ecf-9a86-9b4c37f5f5ac"
version = "0.6.11"

[[deps.ImageBase]]
deps = ["ImageCore", "Reexport"]
git-tree-sha1 = "b51bb8cae22c66d0f6357e3bcb6363145ef20835"
uuid = "c817782e-172a-44cc-b673-b171935fbb9e"
version = "0.1.5"

[[deps.ImageCore]]
deps = ["AbstractFFTs", "ColorVectorSpace", "Colors", "FixedPointNumbers", "Graphics", "MappedArrays", "MosaicViews", "OffsetArrays", "PaddedViews", "Reexport"]
git-tree-sha1 = "acf614720ef026d38400b3817614c45882d75500"
uuid = "a09fc81d-aa75-5fe9-8630-4744c3626534"
version = "0.9.4"

[[deps.ImageIO]]
deps = ["FileIO", "IndirectArrays", "JpegTurbo", "LazyModules", "Netpbm", "OpenEXR", "PNGFiles", "QOI", "Sixel", "TiffImages", "UUIDs"]
git-tree-sha1 = "437abb322a41d527c197fa800455f79d414f0a3c"
uuid = "82e4d734-157c-48bb-816b-45c225c6df19"
version = "0.6.8"

[[deps.ImageMetadata]]
deps = ["AxisArrays", "ImageAxes", "ImageBase", "ImageCore"]
git-tree-sha1 = "355e2b974f2e3212a75dfb60519de21361ad3cb7"
uuid = "bc367c6b-8a6b-528e-b4bd-a4b897500b49"
version = "0.9.9"

[[deps.Imath_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "0936ba688c6d201805a83da835b55c61a180db52"
uuid = "905a6f67-0a94-5f89-b386-d35d92009cd1"
version = "3.1.11+0"

[[deps.IndirectArrays]]
git-tree-sha1 = "012e604e1c7458645cb8b436f8fba789a51b257f"
uuid = "9b13fd28-a010-5f03-acff-a1bbcff69959"
version = "1.0.0"

[[deps.Inflate]]
git-tree-sha1 = "d1b1b796e47d94588b3757fe84fbf65a5ec4a80d"
uuid = "d25df0c9-e2be-5dd7-82c8-3ad0b3e990b9"
version = "0.1.5"

[[deps.IntegerMathUtils]]
git-tree-sha1 = "b8ffb903da9f7b8cf695a8bead8e01814aa24b30"
uuid = "18e54dd8-cb9d-406c-a71d-865a43cbb235"
version = "0.1.2"

[[deps.IntelOpenMP_jll]]
deps = ["Artifacts", "JLLWrappers", "LazyArtifacts", "Libdl"]
git-tree-sha1 = "10bd689145d2c3b2a9844005d01087cc1194e79e"
uuid = "1d5cc7b8-4909-519e-a0f8-d0f5ad9712d0"
version = "2024.2.1+0"

[[deps.InteractiveUtils]]
deps = ["Markdown"]
uuid = "b77e0a4c-d291-57a0-90e8-8db25a27a240"
version = "1.11.0"

[[deps.Interpolations]]
deps = ["Adapt", "AxisAlgorithms", "ChainRulesCore", "LinearAlgebra", "OffsetArrays", "Random", "Ratios", "Requires", "SharedArrays", "SparseArrays", "StaticArrays", "WoodburyMatrices"]
git-tree-sha1 = "88a101217d7cb38a7b481ccd50d21876e1d1b0e0"
uuid = "a98d9a8b-a2ab-59e6-89dd-64a1c18fca59"
version = "0.15.1"

    [deps.Interpolations.extensions]
    InterpolationsUnitfulExt = "Unitful"

    [deps.Interpolations.weakdeps]
    Unitful = "1986cc42-f94f-5a68-af5c-568840ba703d"

[[deps.IntervalArithmetic]]
deps = ["CRlibm_jll", "LinearAlgebra", "MacroTools", "RoundingEmulator"]
git-tree-sha1 = "24c095b1ec7ee58b936985d31d5df92f9b9cfebb"
uuid = "d1acc4aa-44c8-5952-acd4-ba5d80a2a253"
version = "0.22.19"
weakdeps = ["DiffRules", "ForwardDiff", "IntervalSets", "RecipesBase"]

    [deps.IntervalArithmetic.extensions]
    IntervalArithmeticDiffRulesExt = "DiffRules"
    IntervalArithmeticForwardDiffExt = "ForwardDiff"
    IntervalArithmeticIntervalSetsExt = "IntervalSets"
    IntervalArithmeticRecipesBaseExt = "RecipesBase"

[[deps.IntervalSets]]
git-tree-sha1 = "dba9ddf07f77f60450fe5d2e2beb9854d9a49bd0"
uuid = "8197267c-284f-5f27-9208-e0e47529a953"
version = "0.7.10"
weakdeps = ["Random", "RecipesBase", "Statistics"]

    [deps.IntervalSets.extensions]
    IntervalSetsRandomExt = "Random"
    IntervalSetsRecipesBaseExt = "RecipesBase"
    IntervalSetsStatisticsExt = "Statistics"

[[deps.IrrationalConstants]]
git-tree-sha1 = "630b497eafcc20001bba38a4651b327dcfc491d2"
uuid = "92d709cd-6900-40b7-9082-c6be49f344b6"
version = "0.2.2"

[[deps.Isoband]]
deps = ["isoband_jll"]
git-tree-sha1 = "f9b6d97355599074dc867318950adaa6f9946137"
uuid = "f1662d9f-8043-43de-a69a-05efc1cc6ff4"
version = "0.1.1"

[[deps.IterTools]]
git-tree-sha1 = "42d5f897009e7ff2cf88db414a389e5ed1bdd023"
uuid = "c8e1da08-722c-5040-9ed9-7db0dc04731e"
version = "1.10.0"

[[deps.IteratorInterfaceExtensions]]
git-tree-sha1 = "a3f24677c21f5bbe9d2a714f95dcd58337fb2856"
uuid = "82899510-4779-5014-852e-03e436cf321d"
version = "1.0.0"

[[deps.JLLWrappers]]
deps = ["Artifacts", "Preferences"]
git-tree-sha1 = "be3dc50a92e5a386872a493a10050136d4703f9b"
uuid = "692b3bcd-3c85-4b1f-b108-f13ce0eb3210"
version = "1.6.1"

[[deps.JSON]]
deps = ["Dates", "Mmap", "Parsers", "Unicode"]
git-tree-sha1 = "31e996f0a15c7b280ba9f76636b3ff9e2ae58c9a"
uuid = "682c06a0-de6a-54ab-a142-c8b1cf79cde6"
version = "0.21.4"

[[deps.JpegTurbo]]
deps = ["CEnum", "FileIO", "ImageCore", "JpegTurbo_jll", "TOML"]
git-tree-sha1 = "fa6d0bcff8583bac20f1ffa708c3913ca605c611"
uuid = "b835a17e-a41a-41e7-81f0-2f016b05efe0"
version = "0.1.5"

[[deps.JpegTurbo_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "25ee0be4d43d0269027024d75a24c24d6c6e590c"
uuid = "aacddb02-875f-59d6-b918-886e6ef4fbf8"
version = "3.0.4+0"

[[deps.KernelDensity]]
deps = ["Distributions", "DocStringExtensions", "FFTW", "Interpolations", "StatsBase"]
git-tree-sha1 = "7d703202e65efa1369de1279c162b915e245eed1"
uuid = "5ab0869b-81aa-558d-bb23-cbf5423bbe9b"
version = "0.6.9"

[[deps.LAME_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "170b660facf5df5de098d866564877e119141cbd"
uuid = "c1c5ebd0-6772-5130-a774-d5fcae4a789d"
version = "3.100.2+0"

[[deps.LLVMOpenMP_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "78211fb6cbc872f77cad3fc0b6cf647d923f4929"
uuid = "1d63c593-3942-5779-bab2-d838dc0a180e"
version = "18.1.7+0"

[[deps.LZO_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "854a9c268c43b77b0a27f22d7fab8d33cdb3a731"
uuid = "dd4b983a-f0e5-5f8d-a1b7-129d4a5fb1ac"
version = "2.10.2+1"

[[deps.LaTeXStrings]]
git-tree-sha1 = "dda21b8cbd6a6c40d9d02a73230f9d70fed6918c"
uuid = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
version = "1.4.0"

[[deps.LazyArtifacts]]
deps = ["Artifacts", "Pkg"]
uuid = "4af54fe1-eca0-43a8-85a7-787d91b784e3"
version = "1.11.0"

[[deps.LazyModules]]
git-tree-sha1 = "a560dd966b386ac9ae60bdd3a3d3a326062d3c3e"
uuid = "8cdb02fc-e678-4876-92c5-9defec4f444e"
version = "0.3.1"

[[deps.LibCURL]]
deps = ["LibCURL_jll", "MozillaCACerts_jll"]
uuid = "b27032c2-a3e7-50c8-80cd-2d36dbcbfd21"
version = "0.6.4"

[[deps.LibCURL_jll]]
deps = ["Artifacts", "LibSSH2_jll", "Libdl", "MbedTLS_jll", "Zlib_jll", "nghttp2_jll"]
uuid = "deac9b47-8bc7-5906-a0fe-35ac56dc84c0"
version = "8.6.0+0"

[[deps.LibGit2]]
deps = ["Base64", "LibGit2_jll", "NetworkOptions", "Printf", "SHA"]
uuid = "76f85450-5226-5b5a-8eaa-529ad045b433"
version = "1.11.0"

[[deps.LibGit2_jll]]
deps = ["Artifacts", "LibSSH2_jll", "Libdl", "MbedTLS_jll"]
uuid = "e37daf67-58a4-590a-8e99-b0245dd2ffc5"
version = "1.7.2+0"

[[deps.LibSSH2_jll]]
deps = ["Artifacts", "Libdl", "MbedTLS_jll"]
uuid = "29816b5a-b9ab-546f-933c-edad1886dfa8"
version = "1.11.0+1"

[[deps.Libdl]]
uuid = "8f399da3-3557-5675-b5ff-fb832c97cbdb"
version = "1.11.0"

[[deps.Libffi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "0b4a5d71f3e5200a7dff793393e09dfc2d874290"
uuid = "e9f186c6-92d2-5b65-8a66-fee21dc1b490"
version = "3.2.2+1"

[[deps.Libgcrypt_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgpg_error_jll"]
git-tree-sha1 = "8be878062e0ffa2c3f67bb58a595375eda5de80b"
uuid = "d4300ac3-e22c-5743-9152-c294e39db1e4"
version = "1.11.0+0"

[[deps.Libglvnd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll", "Xorg_libXext_jll"]
git-tree-sha1 = "6f73d1dd803986947b2c750138528a999a6c7733"
uuid = "7e76a0d4-f3c7-5321-8279-8d96eeed0f29"
version = "1.6.0+0"

[[deps.Libgpg_error_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "c6ce1e19f3aec9b59186bdf06cdf3c4fc5f5f3e6"
uuid = "7add5ba3-2f88-524e-9cd5-f83b8a55f7b8"
version = "1.50.0+0"

[[deps.Libiconv_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "61dfdba58e585066d8bce214c5a51eaa0539f269"
uuid = "94ce4f54-9a6c-5748-9c1c-f9c7231a4531"
version = "1.17.0+1"

[[deps.Libmount_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "0c4f9c4f1a50d8f35048fa0532dabbadf702f81e"
uuid = "4b2f31a3-9ecc-558c-b454-b3730dcb73e9"
version = "2.40.1+0"

[[deps.Libuuid_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "5ee6203157c120d79034c748a2acba45b82b8807"
uuid = "38a345b3-de98-5d2b-a5d3-14cd9215e700"
version = "2.40.1+0"

[[deps.LightXML]]
deps = ["Libdl", "XML2_jll"]
git-tree-sha1 = "3a994404d3f6709610701c7dabfc03fed87a81f8"
uuid = "9c8b4983-aa76-5018-a973-4c85ecc9e179"
version = "0.9.1"

[[deps.LineSearches]]
deps = ["LinearAlgebra", "NLSolversBase", "NaNMath", "Parameters", "Printf"]
git-tree-sha1 = "e4c3be53733db1051cc15ecf573b1042b3a712a1"
uuid = "d3d80556-e9d4-5f37-9878-2ab0fcc64255"
version = "7.3.0"

[[deps.LinearAlgebra]]
deps = ["Libdl", "OpenBLAS_jll", "libblastrampoline_jll"]
uuid = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"
version = "1.11.0"

[[deps.LinearAlgebraX]]
deps = ["LinearAlgebra", "Mods", "Primes", "SimplePolynomials"]
git-tree-sha1 = "054fe197a75adcf517933f0c807051d79881f3f3"
uuid = "9b3f67b0-2d00-526e-9884-9e4938f8fb88"
version = "0.2.10"

[[deps.LinearElasticity_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "71e8ee0f9fe0e86a8f8c7f28361e5118eab2f93f"
uuid = "18c40d15-f7cd-5a6d-bc92-87468d86c5db"
version = "5.0.0+0"

[[deps.LogExpFunctions]]
deps = ["DocStringExtensions", "IrrationalConstants", "LinearAlgebra"]
git-tree-sha1 = "a2d09619db4e765091ee5c6ffe8872849de0feea"
uuid = "2ab3a3ac-af41-5b50-aa03-7779005ae688"
version = "0.3.28"

    [deps.LogExpFunctions.extensions]
    LogExpFunctionsChainRulesCoreExt = "ChainRulesCore"
    LogExpFunctionsChangesOfVariablesExt = "ChangesOfVariables"
    LogExpFunctionsInverseFunctionsExt = "InverseFunctions"

    [deps.LogExpFunctions.weakdeps]
    ChainRulesCore = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
    ChangesOfVariables = "9e997f8a-9a97-42d5-a9f1-ce6bfc15e2c0"
    InverseFunctions = "3587e190-3f89-42d0-90ee-14403ec27112"

[[deps.Logging]]
uuid = "56ddb016-857b-54e1-b83d-db4d58db5568"
version = "1.11.0"

[[deps.METIS_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "1fd0a97409e418b78c53fac671cf4622efdf0f21"
uuid = "d00139f3-1899-568f-a2f0-47f597d42d70"
version = "5.1.2+0"

[[deps.MIMEs]]
git-tree-sha1 = "65f28ad4b594aebe22157d6fac869786a255b7eb"
uuid = "6c6e2e6c-3030-632d-7369-2d6c69616d65"
version = "0.1.4"

[[deps.MKL_jll]]
deps = ["Artifacts", "IntelOpenMP_jll", "JLLWrappers", "LazyArtifacts", "Libdl", "oneTBB_jll"]
git-tree-sha1 = "f046ccd0c6db2832a9f639e2c669c6fe867e5f4f"
uuid = "856f044c-d86e-5d09-b602-aeab76dc8ba7"
version = "2024.2.0+0"

[[deps.MMG_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "LinearElasticity_jll", "Pkg", "SCOTCH_jll"]
git-tree-sha1 = "70a59df96945782bb0d43b56d0fbfdf1ce2e4729"
uuid = "86086c02-e288-5929-a127-40944b0018b7"
version = "5.6.0+0"

[[deps.MacroTools]]
deps = ["Markdown", "Random"]
git-tree-sha1 = "2fa9ee3e63fd3a4f7a9a4f4744a52f4856de82df"
uuid = "1914dd2f-81c6-5fcd-8719-6d5c9610ff09"
version = "0.5.13"

[[deps.Makie]]
deps = ["Animations", "Base64", "CRC32c", "ColorBrewer", "ColorSchemes", "ColorTypes", "Colors", "Contour", "DelaunayTriangulation", "Distributions", "DocStringExtensions", "Downloads", "FFMPEG_jll", "FileIO", "FixedPointNumbers", "Formatting", "FreeType", "FreeTypeAbstraction", "GeometryBasics", "GridLayoutBase", "ImageIO", "InteractiveUtils", "IntervalSets", "Isoband", "KernelDensity", "LaTeXStrings", "LinearAlgebra", "MacroTools", "MakieCore", "Markdown", "MathTeXEngine", "Observables", "OffsetArrays", "Packing", "PlotUtils", "PolygonOps", "PrecompileTools", "Printf", "REPL", "Random", "RelocatableFolders", "Setfield", "ShaderAbstractions", "Showoff", "SignedDistanceFields", "SparseArrays", "StableHashTraits", "Statistics", "StatsBase", "StatsFuns", "StructArrays", "TriplotBase", "UnicodeFun"]
git-tree-sha1 = "35fa3c150cd96fd77417a23965b7037b90d6ffc9"
uuid = "ee78f7c6-11fb-53f2-987a-cfe4a2b5a57a"
version = "0.19.12"

[[deps.MakieCore]]
deps = ["Observables", "REPL"]
git-tree-sha1 = "9b11acd07f21c4d035bd4156e789532e8ee2cc70"
uuid = "20f20a25-4f0e-4fdf-b5d1-57303727442b"
version = "0.6.9"

[[deps.MappedArrays]]
git-tree-sha1 = "2dab0221fe2b0f2cb6754eaa743cc266339f527e"
uuid = "dbb5928d-eab1-5f90-85c2-b9b0edb7c900"
version = "0.4.2"

[[deps.Markdown]]
deps = ["Base64"]
uuid = "d6f4376e-aef5-505a-96c1-9c027394607a"
version = "1.11.0"

[[deps.MathTeXEngine]]
deps = ["AbstractTrees", "Automa", "DataStructures", "FreeTypeAbstraction", "GeometryBasics", "LaTeXStrings", "REPL", "RelocatableFolders", "UnicodeFun"]
git-tree-sha1 = "96ca8a313eb6437db5ffe946c457a401bbb8ce1d"
uuid = "0a4f8689-d25c-4efe-a92b-7142dfc1aa53"
version = "0.5.7"

[[deps.MbedTLS_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "c8ffd9c3-330d-5841-b78e-0817d7145fa1"
version = "2.28.6+0"

[[deps.MeshIO]]
deps = ["ColorTypes", "FileIO", "GeometryBasics", "Printf"]
git-tree-sha1 = "dc182956229ff16d5a4d90a562035e633bd2561d"
uuid = "7269a6da-0436-5bbc-96c2-40638cbb6118"
version = "0.4.12"

[[deps.Missings]]
deps = ["DataAPI"]
git-tree-sha1 = "ec4f7fbeab05d7747bdf98eb74d130a2a2ed298d"
uuid = "e1d29d7a-bbdc-5cf2-9ac0-f12de2c33e28"
version = "1.2.0"

[[deps.Mmap]]
uuid = "a63ad114-7e13-5084-954f-fe012c677804"
version = "1.11.0"

[[deps.ModernGL]]
deps = ["Libdl"]
git-tree-sha1 = "b76ea40b5c0f45790ae09492712dd326208c28b2"
uuid = "66fc600b-dfda-50eb-8b99-91cfa97b1301"
version = "1.1.7"

[[deps.Mods]]
git-tree-sha1 = "0a3c164857cfc4defe0ac09e6b0123d61320abb1"
uuid = "7475f97c-0381-53b1-977b-4c60186c8d62"
version = "2.2.6"

[[deps.MosaicViews]]
deps = ["MappedArrays", "OffsetArrays", "PaddedViews", "StackViews"]
git-tree-sha1 = "7b86a5d4d70a9f5cdf2dacb3cbe6d251d1a61dbe"
uuid = "e94cdb99-869f-56ef-bcf0-1ae2bcbe0389"
version = "0.3.4"

[[deps.MozillaCACerts_jll]]
uuid = "14a3606d-f60d-562e-9121-12d972cd8159"
version = "2023.12.12"

[[deps.Multisets]]
git-tree-sha1 = "8ef67bad0a3def6d77aebf1d3645119e7c8e5a54"
uuid = "3b2b4ff1-bcff-5658-a3ee-dbcf1ce5ac09"
version = "0.4.5"

[[deps.NLSolversBase]]
deps = ["DiffResults", "Distributed", "FiniteDiff", "ForwardDiff"]
git-tree-sha1 = "a0b464d183da839699f4c79e7606d9d186ec172c"
uuid = "d41bc354-129a-5804-8e4c-c37616107c6c"
version = "7.8.3"

[[deps.NaNMath]]
deps = ["OpenLibm_jll"]
git-tree-sha1 = "0877504529a3e5c3343c6f8b4c0381e57e4387e4"
uuid = "77ba4419-2d1f-58cd-9bb1-8ffee604a2e3"
version = "1.0.2"

[[deps.NearestNeighbors]]
deps = ["Distances", "StaticArrays"]
git-tree-sha1 = "3cebfc94a0754cc329ebc3bab1e6c89621e791ad"
uuid = "b8a86587-4115-5ab1-83bc-aa920d37bbce"
version = "0.4.20"

[[deps.Netpbm]]
deps = ["FileIO", "ImageCore", "ImageMetadata"]
git-tree-sha1 = "d92b107dbb887293622df7697a2223f9f8176fcd"
uuid = "f09324ee-3d7c-5217-9330-fc30815ba969"
version = "1.1.1"

[[deps.NetworkOptions]]
uuid = "ca575930-c2e3-43a9-ace4-1e988b2c1908"
version = "1.2.0"

[[deps.OCCT_jll]]
deps = ["Artifacts", "FreeType2_jll", "JLLWrappers", "Libdl", "Libglvnd_jll", "Pkg", "Xorg_libX11_jll", "Xorg_libXext_jll", "Xorg_libXfixes_jll", "Xorg_libXft_jll", "Xorg_libXinerama_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "acc8099ae8ed10226dc8424fb256ec9fe367a1f0"
uuid = "baad4e97-8daa-5946-aac2-2edac59d34e1"
version = "7.6.2+2"

[[deps.Observables]]
git-tree-sha1 = "7438a59546cf62428fc9d1bc94729146d37a7225"
uuid = "510215fc-4207-5dde-b226-833fc4488ee2"
version = "0.5.5"

[[deps.OffsetArrays]]
git-tree-sha1 = "1a27764e945a152f7ca7efa04de513d473e9542e"
uuid = "6fe1bfb0-de20-5000-8ca7-80f57d26f881"
version = "1.14.1"
weakdeps = ["Adapt"]

    [deps.OffsetArrays.extensions]
    OffsetArraysAdaptExt = "Adapt"

[[deps.Ogg_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "887579a3eb005446d514ab7aeac5d1d027658b8f"
uuid = "e7412a2a-1a6e-54c0-be00-318e2571c051"
version = "1.3.5+1"

[[deps.OpenBLAS_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "Libdl"]
uuid = "4536629a-c528-5b80-bd46-f80d51c5b363"
version = "0.3.27+1"

[[deps.OpenEXR]]
deps = ["Colors", "FileIO", "OpenEXR_jll"]
git-tree-sha1 = "97db9e07fe2091882c765380ef58ec553074e9c7"
uuid = "52e1d378-f018-4a11-a4be-720524705ac7"
version = "0.3.3"

[[deps.OpenEXR_jll]]
deps = ["Artifacts", "Imath_jll", "JLLWrappers", "Libdl", "Zlib_jll"]
git-tree-sha1 = "8292dd5c8a38257111ada2174000a33745b06d4e"
uuid = "18a262bb-aa17-5467-a713-aee519bc75cb"
version = "3.2.4+0"

[[deps.OpenLibm_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "05823500-19ac-5b8b-9628-191a04bc5112"
version = "0.8.1+2"

[[deps.OpenSSL_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "ad31332567b189f508a3ea8957a2640b1147ab00"
uuid = "458c3c95-2e84-50aa-8efc-19380b2a3a95"
version = "1.1.23+1"

[[deps.OpenSpecFun_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "13652491f6856acfd2db29360e1bbcd4565d04f1"
uuid = "efe28fd5-8261-553b-a9e1-b2916fc3738e"
version = "0.5.5+0"

[[deps.Optim]]
deps = ["Compat", "FillArrays", "ForwardDiff", "LineSearches", "LinearAlgebra", "NLSolversBase", "NaNMath", "Parameters", "PositiveFactorizations", "Printf", "SparseArrays", "StatsBase"]
git-tree-sha1 = "d9b79c4eed437421ac4285148fcadf42e0700e89"
uuid = "429524aa-4258-5aef-a3af-852621145aeb"
version = "1.9.4"

    [deps.Optim.extensions]
    OptimMOIExt = "MathOptInterface"

    [deps.Optim.weakdeps]
    MathOptInterface = "b8f27783-ece8-5eb3-8dc8-9495eed66fee"

[[deps.Opus_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "6703a85cb3781bd5909d48730a67205f3f31a575"
uuid = "91d4177d-7536-5919-b921-800302f37372"
version = "1.3.3+0"

[[deps.OrderedCollections]]
git-tree-sha1 = "dfdf5519f235516220579f949664f1bf44e741c5"
uuid = "bac558e1-5e72-5ebc-8fee-abe8a469f55d"
version = "1.6.3"

[[deps.PCRE2_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "efcefdf7-47ab-520b-bdef-62a2eaa19f15"
version = "10.42.0+1"

[[deps.PDMats]]
deps = ["LinearAlgebra", "SparseArrays", "SuiteSparse"]
git-tree-sha1 = "949347156c25054de2db3b166c52ac4728cbad65"
uuid = "90014a1f-27ba-587c-ab20-58faa44d9150"
version = "0.11.31"

[[deps.PNGFiles]]
deps = ["Base64", "CEnum", "ImageCore", "IndirectArrays", "OffsetArrays", "libpng_jll"]
git-tree-sha1 = "67186a2bc9a90f9f85ff3cc8277868961fb57cbd"
uuid = "f57f5aa1-a3ce-4bc8-8ab9-96f992907883"
version = "0.4.3"

[[deps.Packing]]
deps = ["GeometryBasics"]
git-tree-sha1 = "ec3edfe723df33528e085e632414499f26650501"
uuid = "19eb6ba3-879d-56ad-ad62-d5c202156566"
version = "0.5.0"

[[deps.PaddedViews]]
deps = ["OffsetArrays"]
git-tree-sha1 = "0fac6313486baae819364c52b4f483450a9d793f"
uuid = "5432bcbf-9aad-5242-b902-cca2824c8663"
version = "0.5.12"

[[deps.Pango_jll]]
deps = ["Artifacts", "Cairo_jll", "Fontconfig_jll", "FreeType2_jll", "FriBidi_jll", "Glib_jll", "HarfBuzz_jll", "JLLWrappers", "Libdl"]
git-tree-sha1 = "e127b609fb9ecba6f201ba7ab753d5a605d53801"
uuid = "36c8627f-9965-5494-a995-c6b170f724f3"
version = "1.54.1+0"

[[deps.Parameters]]
deps = ["OrderedCollections", "UnPack"]
git-tree-sha1 = "34c0e9ad262e5f7fc75b10a9952ca7692cfc5fbe"
uuid = "d96e819e-fc66-5662-9728-84c9c7592b0a"
version = "0.12.3"

[[deps.Parsers]]
deps = ["Dates", "PrecompileTools", "UUIDs"]
git-tree-sha1 = "8489905bcdbcfac64d1daa51ca07c0d8f0283821"
uuid = "69de0a69-1ddd-5017-9359-2bf0b02dc9f0"
version = "2.8.1"

[[deps.Permutations]]
deps = ["Combinatorics", "LinearAlgebra", "Random"]
git-tree-sha1 = "f92b0a7b722b1ecfd5c0d77a7eda24b4eea5c56a"
uuid = "2ae35dd2-176d-5d53-8349-f30d82d94d4f"
version = "0.4.22"

[[deps.PikaParser]]
deps = ["DocStringExtensions"]
git-tree-sha1 = "d6ff87de27ff3082131f31a714d25ab6d0a88abf"
uuid = "3bbf5609-3e7b-44cd-8549-7c69f321e792"
version = "0.6.1"

[[deps.Pixman_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "LLVMOpenMP_jll", "Libdl"]
git-tree-sha1 = "35621f10a7531bc8fa58f74610b1bfb70a3cfc6b"
uuid = "30392449-352a-5448-841d-b1acce4e97dc"
version = "0.43.4+0"

[[deps.Pkg]]
deps = ["Artifacts", "Dates", "Downloads", "FileWatching", "LibGit2", "Libdl", "Logging", "Markdown", "Printf", "Random", "SHA", "TOML", "Tar", "UUIDs", "p7zip_jll"]
uuid = "44cfe95a-1eb2-52ea-b672-e2afdf69b78f"
version = "1.11.0"
weakdeps = ["REPL"]

    [deps.Pkg.extensions]
    REPLExt = "REPL"

[[deps.PkgVersion]]
deps = ["Pkg"]
git-tree-sha1 = "f9501cc0430a26bc3d156ae1b5b0c1b47af4d6da"
uuid = "eebad327-c553-4316-9ea0-9fa01ccd7688"
version = "0.3.3"

[[deps.PlotUtils]]
deps = ["ColorSchemes", "Colors", "Dates", "PrecompileTools", "Printf", "Random", "Reexport", "StableRNGs", "Statistics"]
git-tree-sha1 = "3ca9a356cd2e113c420f2c13bea19f8d3fb1cb18"
uuid = "995b91a9-d308-5afd-9ec6-746e21dbc043"
version = "1.4.3"

[[deps.PlutoUI]]
deps = ["AbstractPlutoDingetjes", "Base64", "ColorTypes", "Dates", "FixedPointNumbers", "Hyperscript", "HypertextLiteral", "IOCapture", "InteractiveUtils", "JSON", "Logging", "MIMEs", "Markdown", "Random", "Reexport", "URIs", "UUIDs"]
git-tree-sha1 = "eba4810d5e6a01f612b948c9fa94f905b49087b0"
uuid = "7f904dfe-b85e-4ff6-b463-dae2292396a8"
version = "0.7.60"

[[deps.PolygonOps]]
git-tree-sha1 = "77b3d3605fc1cd0b42d95eba87dfcd2bf67d5ff6"
uuid = "647866c9-e3ac-4575-94e7-e3d426903924"
version = "0.1.2"

[[deps.Polynomials]]
deps = ["LinearAlgebra", "RecipesBase", "Requires", "Setfield", "SparseArrays"]
git-tree-sha1 = "1a9cfb2dc2c2f1bd63f1906d72af39a79b49b736"
uuid = "f27b6e38-b328-58d1-80ce-0feddd5e7a45"
version = "4.0.11"

    [deps.Polynomials.extensions]
    PolynomialsChainRulesCoreExt = "ChainRulesCore"
    PolynomialsFFTWExt = "FFTW"
    PolynomialsMakieCoreExt = "MakieCore"
    PolynomialsMutableArithmeticsExt = "MutableArithmetics"

    [deps.Polynomials.weakdeps]
    ChainRulesCore = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
    FFTW = "7a1cc6ca-52ef-59f5-83cd-3a7055c09341"
    MakieCore = "20f20a25-4f0e-4fdf-b5d1-57303727442b"
    MutableArithmetics = "d8a4904e-b15c-11e9-3269-09a3773c0cb0"

[[deps.PositiveFactorizations]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "17275485f373e6673f7e7f97051f703ed5b15b20"
uuid = "85a6dd25-e78a-55b7-8502-1745935b8125"
version = "0.2.4"

[[deps.PrecompileTools]]
deps = ["Preferences"]
git-tree-sha1 = "5aa36f7049a63a1528fe8f7c3f2113413ffd4e1f"
uuid = "aea7be01-6a6a-4083-8856-8a6e6704d82a"
version = "1.2.1"

[[deps.Preferences]]
deps = ["TOML"]
git-tree-sha1 = "9306f6085165d270f7e3db02af26a400d580f5c6"
uuid = "21216c6a-2e73-6563-6e65-726566657250"
version = "1.4.3"

[[deps.Primes]]
deps = ["IntegerMathUtils"]
git-tree-sha1 = "cb420f77dc474d23ee47ca8d14c90810cafe69e7"
uuid = "27ebfcd6-29c5-5fa9-bf4b-fb8fc14df3ae"
version = "0.5.6"

[[deps.Printf]]
deps = ["Unicode"]
uuid = "de0858da-6303-5e67-8744-51eddeeeb8d7"
version = "1.11.0"

[[deps.ProgressMeter]]
deps = ["Distributed", "Printf"]
git-tree-sha1 = "8f6bc219586aef8baf0ff9a5fe16ee9c70cb65e4"
uuid = "92933f4c-e287-5a05-a399-4b506db050ca"
version = "1.10.2"

[[deps.PtrArrays]]
git-tree-sha1 = "77a42d78b6a92df47ab37e177b2deac405e1c88f"
uuid = "43287f4e-b6f4-7ad1-bb20-aadabca52c3d"
version = "1.2.1"

[[deps.QOI]]
deps = ["ColorTypes", "FileIO", "FixedPointNumbers"]
git-tree-sha1 = "18e8f4d1426e965c7b532ddd260599e1510d26ce"
uuid = "4b34888f-f399-49d4-9bb3-47ed5cae4e65"
version = "1.0.0"

[[deps.QuadGK]]
deps = ["DataStructures", "LinearAlgebra"]
git-tree-sha1 = "cda3b045cf9ef07a08ad46731f5a3165e56cf3da"
uuid = "1fd47b50-473d-5c70-9696-f719f8f3bcdc"
version = "2.11.1"

    [deps.QuadGK.extensions]
    QuadGKEnzymeExt = "Enzyme"

    [deps.QuadGK.weakdeps]
    Enzyme = "7da242da-08ed-463a-9acd-ee780be4f1d9"

[[deps.REPL]]
deps = ["InteractiveUtils", "Markdown", "Sockets", "StyledStrings", "Unicode"]
uuid = "3fa0cd96-eef1-5676-8a61-b3b8758bbffb"
version = "1.11.0"

[[deps.Random]]
deps = ["SHA"]
uuid = "9a3f8284-a2c9-5f02-9a11-845980a1fd5c"
version = "1.11.0"

[[deps.RangeArrays]]
git-tree-sha1 = "b9039e93773ddcfc828f12aadf7115b4b4d225f5"
uuid = "b3c3ace0-ae52-54e7-9d0b-2c1406fd6b9d"
version = "0.3.2"

[[deps.Ratios]]
deps = ["Requires"]
git-tree-sha1 = "1342a47bf3260ee108163042310d26f2be5ec90b"
uuid = "c84ed2f1-dad5-54f0-aa8e-dbefe2724439"
version = "0.4.5"
weakdeps = ["FixedPointNumbers"]

    [deps.Ratios.extensions]
    RatiosFixedPointNumbersExt = "FixedPointNumbers"

[[deps.RecipesBase]]
deps = ["PrecompileTools"]
git-tree-sha1 = "5c3d09cc4f31f5fc6af001c250bf1278733100ff"
uuid = "3cdcf5f2-1ef4-517c-9805-6587b60abb01"
version = "1.3.4"

[[deps.Reexport]]
git-tree-sha1 = "45e428421666073eab6f2da5c9d310d99bb12f9b"
uuid = "189a3867-3050-52da-a836-e630ba90ab69"
version = "1.2.2"

[[deps.RelocatableFolders]]
deps = ["SHA", "Scratch"]
git-tree-sha1 = "ffdaf70d81cf6ff22c2b6e733c900c3321cab864"
uuid = "05181044-ff0b-4ac5-8273-598c1e38db00"
version = "1.0.1"

[[deps.Requires]]
deps = ["UUIDs"]
git-tree-sha1 = "838a3a4188e2ded87a4f9f184b4b0d78a1e91cb7"
uuid = "ae029012-a4dd-5104-9daa-d747884805df"
version = "1.3.0"

[[deps.RingLists]]
deps = ["Random"]
git-tree-sha1 = "70d8d52c6d4238cace6ae1a7dd2c0c4d43acdf0b"
uuid = "286e9d63-9694-5540-9e3c-4e6708fa07b2"
version = "0.2.9"

[[deps.Rmath]]
deps = ["Random", "Rmath_jll"]
git-tree-sha1 = "852bd0f55565a9e973fcfee83a84413270224dc4"
uuid = "79098fc4-a85e-5d69-aa6a-4863f24498fa"
version = "0.8.0"

[[deps.Rmath_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "58cdd8fb2201a6267e1db87ff148dd6c1dbd8ad8"
uuid = "f50d1b31-88e8-58de-be2c-1cc44531875f"
version = "0.5.1+0"

[[deps.RoundingEmulator]]
git-tree-sha1 = "40b9edad2e5287e05bd413a38f61a8ff55b9557b"
uuid = "5eaf0fd0-dfba-4ccb-bf02-d820a40db705"
version = "0.2.1"

[[deps.SCOTCH_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "7110b749766853054ce8a2afaa73325d72d32129"
uuid = "a8d0f55d-b80e-548d-aff6-1a04c175f0f9"
version = "6.1.3+0"

[[deps.SHA]]
uuid = "ea8e919c-243c-51af-8825-aaa63cd721ce"
version = "0.7.0"

[[deps.SIMD]]
deps = ["PrecompileTools"]
git-tree-sha1 = "98ca7c29edd6fc79cd74c61accb7010a4e7aee33"
uuid = "fdea26ae-647d-5447-a871-4b548cad5224"
version = "3.6.0"

[[deps.Scratch]]
deps = ["Dates"]
git-tree-sha1 = "3bac05bc7e74a75fd9cba4295cde4045d9fe2386"
uuid = "6c6a2e73-6563-6170-7368-637461726353"
version = "1.2.1"

[[deps.Serialization]]
uuid = "9e88b42a-f829-5b0c-bbe9-9e923198166b"
version = "1.11.0"

[[deps.Setfield]]
deps = ["ConstructionBase", "Future", "MacroTools", "StaticArraysCore"]
git-tree-sha1 = "e2cc6d8c88613c05e1defb55170bf5ff211fbeac"
uuid = "efcf1570-3423-57d1-acb7-fd33fddbac46"
version = "1.1.1"

[[deps.ShaderAbstractions]]
deps = ["ColorTypes", "FixedPointNumbers", "GeometryBasics", "LinearAlgebra", "Observables", "StaticArrays", "StructArrays", "Tables"]
git-tree-sha1 = "79123bc60c5507f035e6d1d9e563bb2971954ec8"
uuid = "65257c39-d410-5151-9873-9b3e5be5013e"
version = "0.4.1"

[[deps.SharedArrays]]
deps = ["Distributed", "Mmap", "Random", "Serialization"]
uuid = "1a1011a3-84de-559e-8e89-a11a2f7dc383"
version = "1.11.0"

[[deps.Showoff]]
deps = ["Dates", "Grisu"]
git-tree-sha1 = "91eddf657aca81df9ae6ceb20b959ae5653ad1de"
uuid = "992d4aef-0814-514b-bc4d-f2e9a6c4116f"
version = "1.0.3"

[[deps.SignedDistanceFields]]
deps = ["Random", "Statistics", "Test"]
git-tree-sha1 = "d263a08ec505853a5ff1c1ebde2070419e3f28e9"
uuid = "73760f76-fbc4-59ce-8f25-708e95d2df96"
version = "0.4.0"

[[deps.SimpleGraphs]]
deps = ["AbstractLattices", "Combinatorics", "DataStructures", "IterTools", "LightXML", "LinearAlgebra", "LinearAlgebraX", "Optim", "Primes", "Random", "RingLists", "SimplePartitions", "SimplePolynomials", "SimpleRandom", "SparseArrays", "Statistics"]
git-tree-sha1 = "f65caa24a622f985cc341de81d3f9744435d0d0f"
uuid = "55797a34-41de-5266-9ec1-32ac4eb504d3"
version = "0.8.6"

[[deps.SimplePartitions]]
deps = ["AbstractLattices", "DataStructures", "Permutations"]
git-tree-sha1 = "76cdce94e07849d1172ccb8f3a60a0bbbebe58b3"
uuid = "ec83eff0-a5b5-5643-ae32-5cbf6eedec9d"
version = "0.3.3"

[[deps.SimplePolynomials]]
deps = ["Mods", "Multisets", "Polynomials", "Primes"]
git-tree-sha1 = "77b2c5e731f7e50bbd088ccc2810232e06c1afa3"
uuid = "cc47b68c-3164-5771-a705-2bc0097375a0"
version = "0.2.18"

[[deps.SimpleRandom]]
deps = ["Distributions", "LinearAlgebra", "Random"]
git-tree-sha1 = "bb4f42b25b87f124478207a82f5b02dfafdb3e63"
uuid = "a6525b86-64cd-54fa-8f65-62fc48bdc0e8"
version = "0.3.2"

[[deps.SimpleTraits]]
deps = ["InteractiveUtils", "MacroTools"]
git-tree-sha1 = "5d7e3f4e11935503d3ecaf7186eac40602e7d231"
uuid = "699a6c99-e7fa-54fc-8d76-47d257e15c1d"
version = "0.9.4"

[[deps.Sixel]]
deps = ["Dates", "FileIO", "ImageCore", "IndirectArrays", "OffsetArrays", "REPL", "libsixel_jll"]
git-tree-sha1 = "2da10356e31327c7096832eb9cd86307a50b1eb6"
uuid = "45858cf5-a6b0-47a3-bbea-62219f50df47"
version = "0.1.3"

[[deps.SnoopPrecompile]]
deps = ["Preferences"]
git-tree-sha1 = "e760a70afdcd461cf01a575947738d359234665c"
uuid = "66db9d55-30c0-4569-8b51-7e840670fc0c"
version = "1.0.3"

[[deps.Sockets]]
uuid = "6462fe0b-24de-5631-8697-dd941f90decc"
version = "1.11.0"

[[deps.SortingAlgorithms]]
deps = ["DataStructures"]
git-tree-sha1 = "66e0a8e672a0bdfca2c3f5937efb8538b9ddc085"
uuid = "a2af1166-a08f-5f64-846c-94a0d3cef48c"
version = "1.2.1"

[[deps.SparseArrays]]
deps = ["Libdl", "LinearAlgebra", "Random", "Serialization", "SuiteSparse_jll"]
uuid = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"
version = "1.11.0"

[[deps.SpecialFunctions]]
deps = ["IrrationalConstants", "LogExpFunctions", "OpenLibm_jll", "OpenSpecFun_jll"]
git-tree-sha1 = "2f5d4697f21388cbe1ff299430dd169ef97d7e14"
uuid = "276daf66-3868-5448-9aa4-cd146d93841b"
version = "2.4.0"
weakdeps = ["ChainRulesCore"]

    [deps.SpecialFunctions.extensions]
    SpecialFunctionsChainRulesCoreExt = "ChainRulesCore"

[[deps.StableHashTraits]]
deps = ["Compat", "PikaParser", "SHA", "StructTypes", "Tables", "TupleTools", "WeakKeyIdDicts"]
git-tree-sha1 = "e51435f1d289a2c8c97d0f3560af05e3a507be01"
uuid = "c5dd0088-6c3f-4803-b00e-f31a60c170fa"
version = "1.3.3"

[[deps.StableRNGs]]
deps = ["Random"]
git-tree-sha1 = "83e6cce8324d49dfaf9ef059227f91ed4441a8e5"
uuid = "860ef19b-820b-49d6-a774-d7a799459cd3"
version = "1.0.2"

[[deps.StackViews]]
deps = ["OffsetArrays"]
git-tree-sha1 = "46e589465204cd0c08b4bd97385e4fa79a0c770c"
uuid = "cae243ae-269e-4f55-b966-ac2d0dc13c15"
version = "0.1.1"

[[deps.StaticArrays]]
deps = ["LinearAlgebra", "PrecompileTools", "Random", "StaticArraysCore"]
git-tree-sha1 = "777657803913ffc7e8cc20f0fd04b634f871af8f"
uuid = "90137ffa-7385-5640-81b9-e52037218182"
version = "1.9.8"
weakdeps = ["ChainRulesCore", "Statistics"]

    [deps.StaticArrays.extensions]
    StaticArraysChainRulesCoreExt = "ChainRulesCore"
    StaticArraysStatisticsExt = "Statistics"

[[deps.StaticArraysCore]]
git-tree-sha1 = "192954ef1208c7019899fbf8049e717f92959682"
uuid = "1e83bf80-4336-4d27-bf5d-d5a4f845583c"
version = "1.4.3"

[[deps.Statistics]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "ae3bb1eb3bba077cd276bc5cfc337cc65c3075c0"
uuid = "10745b16-79ce-11e8-11f9-7d13ad32a3b2"
version = "1.11.1"
weakdeps = ["SparseArrays"]

    [deps.Statistics.extensions]
    SparseArraysExt = ["SparseArrays"]

[[deps.StatsAPI]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "1ff449ad350c9c4cbc756624d6f8a8c3ef56d3ed"
uuid = "82ae8749-77ed-4fe6-ae5f-f523153014b0"
version = "1.7.0"

[[deps.StatsBase]]
deps = ["DataAPI", "DataStructures", "LinearAlgebra", "LogExpFunctions", "Missings", "Printf", "Random", "SortingAlgorithms", "SparseArrays", "Statistics", "StatsAPI"]
git-tree-sha1 = "5cf7606d6cef84b543b483848d4ae08ad9832b21"
uuid = "2913bbd2-ae8a-5f71-8c99-4fb6c76f3a91"
version = "0.34.3"

[[deps.StatsFuns]]
deps = ["HypergeometricFunctions", "IrrationalConstants", "LogExpFunctions", "Reexport", "Rmath", "SpecialFunctions"]
git-tree-sha1 = "b423576adc27097764a90e163157bcfc9acf0f46"
uuid = "4c63d2b9-4356-54db-8cca-17b64c39e42c"
version = "1.3.2"

    [deps.StatsFuns.extensions]
    StatsFunsChainRulesCoreExt = "ChainRulesCore"
    StatsFunsInverseFunctionsExt = "InverseFunctions"

    [deps.StatsFuns.weakdeps]
    ChainRulesCore = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
    InverseFunctions = "3587e190-3f89-42d0-90ee-14403ec27112"

[[deps.StructArrays]]
deps = ["ConstructionBase", "DataAPI", "Tables"]
git-tree-sha1 = "f4dc295e983502292c4c3f951dbb4e985e35b3be"
uuid = "09ab397b-f2b6-538f-b94a-2f83cf4a842a"
version = "0.6.18"

    [deps.StructArrays.extensions]
    StructArraysAdaptExt = "Adapt"
    StructArraysGPUArraysCoreExt = "GPUArraysCore"
    StructArraysSparseArraysExt = "SparseArrays"
    StructArraysStaticArraysExt = "StaticArrays"

    [deps.StructArrays.weakdeps]
    Adapt = "79e6a3ab-5dfb-504d-930d-738a2a938a0e"
    GPUArraysCore = "46192b85-c4d5-4398-a991-12ede77f4527"
    SparseArrays = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"
    StaticArrays = "90137ffa-7385-5640-81b9-e52037218182"

[[deps.StructTypes]]
deps = ["Dates", "UUIDs"]
git-tree-sha1 = "159331b30e94d7b11379037feeb9b690950cace8"
uuid = "856f2bd8-1eba-4b0a-8007-ebc267875bd4"
version = "1.11.0"

[[deps.StyledStrings]]
uuid = "f489334b-da3d-4c2e-b8f0-e476e12c162b"
version = "1.11.0"

[[deps.SuiteSparse]]
deps = ["Libdl", "LinearAlgebra", "Serialization", "SparseArrays"]
uuid = "4607b0f0-06f3-5cda-b6b1-a6196a1729e9"

[[deps.SuiteSparse_jll]]
deps = ["Artifacts", "Libdl", "libblastrampoline_jll"]
uuid = "bea87d4a-7f5b-5778-9afe-8cc45184846c"
version = "7.7.0+0"

[[deps.TOML]]
deps = ["Dates"]
uuid = "fa267f1f-6049-4f14-aa54-33bafae1ed76"
version = "1.0.3"

[[deps.TableTraits]]
deps = ["IteratorInterfaceExtensions"]
git-tree-sha1 = "c06b2f539df1c6efa794486abfb6ed2022561a39"
uuid = "3783bdb8-4a98-5b6b-af9a-565f29a5fe9c"
version = "1.0.1"

[[deps.Tables]]
deps = ["DataAPI", "DataValueInterfaces", "IteratorInterfaceExtensions", "OrderedCollections", "TableTraits"]
git-tree-sha1 = "598cd7c1f68d1e205689b1c2fe65a9f85846f297"
uuid = "bd369af6-aec1-5ad0-b16a-f7cc5008161c"
version = "1.12.0"

[[deps.Tar]]
deps = ["ArgTools", "SHA"]
uuid = "a4e569a6-e804-4fa4-b0f3-eef7a1d5b13e"
version = "1.10.0"

[[deps.TensorCore]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "1feb45f88d133a655e001435632f019a9a1bcdb6"
uuid = "62fd8b95-f654-4bbd-a8a5-9c27f68ccd50"
version = "0.1.1"

[[deps.Tensors]]
deps = ["ForwardDiff", "LinearAlgebra", "SIMD", "SnoopPrecompile", "StaticArrays", "Statistics"]
git-tree-sha1 = "71f054343e85ab1eab12bf8336004309002ff82d"
uuid = "48a634ad-e948-5137-8d70-aa71f2a747f4"
version = "1.13.1"

[[deps.Test]]
deps = ["InteractiveUtils", "Logging", "Random", "Serialization"]
uuid = "8dfed614-e22c-5e08-85e1-65c5234f0b40"
version = "1.11.0"

[[deps.TiffImages]]
deps = ["ColorTypes", "DataStructures", "DocStringExtensions", "FileIO", "FixedPointNumbers", "IndirectArrays", "Inflate", "Mmap", "OffsetArrays", "PkgVersion", "ProgressMeter", "SIMD", "UUIDs"]
git-tree-sha1 = "38f139cc4abf345dd4f22286ec000728d5e8e097"
uuid = "731e570b-9d59-4bfa-96dc-6df516fadf69"
version = "0.10.2"

[[deps.TranscodingStreams]]
git-tree-sha1 = "0c45878dcfdcfa8480052b6ab162cdd138781742"
uuid = "3bb67fe8-82b1-5028-8e26-92a6c54297fa"
version = "0.11.3"

[[deps.Tricks]]
git-tree-sha1 = "7822b97e99a1672bfb1b49b668a6d46d58d8cbcb"
uuid = "410a4b4d-49e4-4fbc-ab6d-cb71b17b3775"
version = "0.1.9"

[[deps.TriplotBase]]
git-tree-sha1 = "4d4ed7f294cda19382ff7de4c137d24d16adc89b"
uuid = "981d1d27-644d-49a2-9326-4793e63143c3"
version = "0.1.0"

[[deps.TupleTools]]
git-tree-sha1 = "41e43b9dc950775eac654b9f845c839cd2f1821e"
uuid = "9d95972d-f1c8-5527-a6e0-b4b365fa01f6"
version = "1.6.0"

[[deps.URIs]]
git-tree-sha1 = "67db6cc7b3821e19ebe75791a9dd19c9b1188f2b"
uuid = "5c2747f8-b7ea-4ff2-ba2e-563bfd36b1d4"
version = "1.5.1"

[[deps.UUIDs]]
deps = ["Random", "SHA"]
uuid = "cf7118a7-6976-5b1a-9a39-7adc72f591a4"
version = "1.11.0"

[[deps.UnPack]]
git-tree-sha1 = "387c1f73762231e86e0c9c5443ce3b4a0a9a0c2b"
uuid = "3a884ed6-31ef-47d7-9d2a-63182c4928ed"
version = "1.0.2"

[[deps.Unicode]]
uuid = "4ec0a83e-493e-50e2-b9ac-8f72acf5a8f5"
version = "1.11.0"

[[deps.UnicodeFun]]
deps = ["REPL"]
git-tree-sha1 = "53915e50200959667e78a92a418594b428dffddf"
uuid = "1cfade01-22cf-5700-b092-accc4b62d6e1"
version = "0.4.1"

[[deps.VTKBase]]
git-tree-sha1 = "c2d0db3ef09f1942d08ea455a9e252594be5f3b6"
uuid = "4004b06d-e244-455f-a6ce-a5f9919cc534"
version = "1.0.1"

[[deps.Wayland_jll]]
deps = ["Artifacts", "EpollShim_jll", "Expat_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "7558e29847e99bc3f04d6569e82d0f5c54460703"
uuid = "a2964d1f-97da-50d4-b82a-358c7fce9d89"
version = "1.21.0+1"

[[deps.Wayland_protocols_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "93f43ab61b16ddfb2fd3bb13b3ce241cafb0e6c9"
uuid = "2381bf8a-dfd0-557d-9999-79630e7b1b91"
version = "1.31.0+0"

[[deps.WeakKeyIdDicts]]
git-tree-sha1 = "349165887b0cfdcbb97261e7eb0e7f11d7b39845"
uuid = "ecbed89c-9d59-4137-ae1f-d1084086d01c"
version = "0.1.0"

[[deps.WoodburyMatrices]]
deps = ["LinearAlgebra", "SparseArrays"]
git-tree-sha1 = "c1a7aa6219628fcd757dede0ca95e245c5cd9511"
uuid = "efce3f68-66dc-5838-9240-27a6d6f5f9b6"
version = "1.0.0"

[[deps.WriteVTK]]
deps = ["Base64", "CodecZlib", "FillArrays", "LightXML", "TranscodingStreams", "VTKBase"]
git-tree-sha1 = "1d8042d58334ab7947ce505709df7009da6f3375"
uuid = "64499a7a-5c06-52f2-abe2-ccb03c286192"
version = "1.21.1"

[[deps.XML2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libiconv_jll", "Zlib_jll"]
git-tree-sha1 = "6a451c6f33a176150f315726eba8b92fbfdb9ae7"
uuid = "02c8fc9c-b97f-50b9-bbe4-9be30ff0a78a"
version = "2.13.4+0"

[[deps.XSLT_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgcrypt_jll", "Libgpg_error_jll", "Libiconv_jll", "XML2_jll", "Zlib_jll"]
git-tree-sha1 = "a54ee957f4c86b526460a720dbc882fa5edcbefc"
uuid = "aed1982a-8fda-507f-9586-7b0439959a61"
version = "1.1.41+0"

[[deps.Xorg_libX11_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libxcb_jll", "Xorg_xtrans_jll"]
git-tree-sha1 = "afead5aba5aa507ad5a3bf01f58f82c8d1403495"
uuid = "4f6342f7-b3d2-589e-9d20-edeb45f2b2bc"
version = "1.8.6+0"

[[deps.Xorg_libXau_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "6035850dcc70518ca32f012e46015b9beeda49d8"
uuid = "0c0b7dd1-d40b-584c-a123-a41640f87eec"
version = "1.0.11+0"

[[deps.Xorg_libXcursor_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXfixes_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "12e0eb3bc634fa2080c1c37fccf56f7c22989afd"
uuid = "935fb764-8cf2-53bf-bb30-45bb1f8bf724"
version = "1.2.0+4"

[[deps.Xorg_libXdmcp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "34d526d318358a859d7de23da945578e8e8727b7"
uuid = "a3789734-cfe1-5b06-b2d0-1dd0d9d62d05"
version = "1.1.4+0"

[[deps.Xorg_libXext_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libX11_jll"]
git-tree-sha1 = "d2d1a5c49fae4ba39983f63de6afcbea47194e85"
uuid = "1082639a-0dae-5f34-9b06-72781eeb8cb3"
version = "1.3.6+0"

[[deps.Xorg_libXfixes_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "0e0dc7431e7a0587559f9294aeec269471c991a4"
uuid = "d091e8ba-531a-589c-9de9-94069b037ed8"
version = "5.0.3+4"

[[deps.Xorg_libXft_jll]]
deps = ["Fontconfig_jll", "Libdl", "Pkg", "Xorg_libXrender_jll"]
git-tree-sha1 = "754b542cdc1057e0a2f1888ec5414ee17a4ca2a1"
uuid = "2c808117-e144-5220-80d1-69d4eaa9352c"
version = "2.3.3+1"

[[deps.Xorg_libXi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXfixes_jll"]
git-tree-sha1 = "89b52bc2160aadc84d707093930ef0bffa641246"
uuid = "a51aa0fd-4e3c-5386-b890-e753decda492"
version = "1.7.10+4"

[[deps.Xorg_libXinerama_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll"]
git-tree-sha1 = "26be8b1c342929259317d8b9f7b53bf2bb73b123"
uuid = "d1454406-59df-5ea1-beac-c340f2130bc3"
version = "1.1.4+4"

[[deps.Xorg_libXrandr_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "34cea83cb726fb58f325887bf0612c6b3fb17631"
uuid = "ec84b674-ba8e-5d96-8ba1-2a689ba10484"
version = "1.5.2+4"

[[deps.Xorg_libXrender_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libX11_jll"]
git-tree-sha1 = "47e45cd78224c53109495b3e324df0c37bb61fbe"
uuid = "ea2f1a96-1ddc-540d-b46f-429655e07cfa"
version = "0.9.11+0"

[[deps.Xorg_libpthread_stubs_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "8fdda4c692503d44d04a0603d9ac0982054635f9"
uuid = "14d82f49-176c-5ed1-bb49-ad3f5cbd8c74"
version = "0.1.1+0"

[[deps.Xorg_libxcb_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "XSLT_jll", "Xorg_libXau_jll", "Xorg_libXdmcp_jll", "Xorg_libpthread_stubs_jll"]
git-tree-sha1 = "bcd466676fef0878338c61e655629fa7bbc69d8e"
uuid = "c7cfdc94-dc32-55de-ac96-5a1b8d977c5b"
version = "1.17.0+0"

[[deps.Xorg_libxkbfile_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libX11_jll"]
git-tree-sha1 = "730eeca102434283c50ccf7d1ecdadf521a765a4"
uuid = "cc61e674-0454-545c-8b26-ed2c68acab7a"
version = "1.1.2+0"

[[deps.Xorg_xkbcomp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libxkbfile_jll"]
git-tree-sha1 = "330f955bc41bb8f5270a369c473fc4a5a4e4d3cb"
uuid = "35661453-b289-5fab-8a00-3d9160c6a3a4"
version = "1.4.6+0"

[[deps.Xorg_xkeyboard_config_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_xkbcomp_jll"]
git-tree-sha1 = "691634e5453ad362044e2ad653e79f3ee3bb98c3"
uuid = "33bec58e-1273-512f-9401-5d533626f822"
version = "2.39.0+0"

[[deps.Xorg_xtrans_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "e92a1a012a10506618f10b7047e478403a046c77"
uuid = "c5fb5394-a638-5e4d-96e5-b29de1b5cf10"
version = "1.5.0+0"

[[deps.Zlib_jll]]
deps = ["Libdl"]
uuid = "83775a58-1f1d-513f-b197-d71354ab007a"
version = "1.2.13+1"

[[deps.gmsh_jll]]
deps = ["Artifacts", "Cairo_jll", "CompilerSupportLibraries_jll", "FLTK_jll", "FreeType2_jll", "GLU_jll", "GMP_jll", "HDF5_jll", "JLLWrappers", "JpegTurbo_jll", "LLVMOpenMP_jll", "Libdl", "Libglvnd_jll", "METIS_jll", "MMG_jll", "OCCT_jll", "Pkg", "Xorg_libX11_jll", "Xorg_libXext_jll", "Xorg_libXfixes_jll", "Xorg_libXft_jll", "Xorg_libXinerama_jll", "Xorg_libXrender_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "d4cf3bb87fa0669f569e51f6f06cd083771bab65"
uuid = "630162c2-fc9b-58b3-9910-8442a8a132e6"
version = "4.10.2+1"

[[deps.isoband_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "51b5eeb3f98367157a7a12a1fb0aa5328946c03c"
uuid = "9a68df92-36a6-505f-a73e-abb412b6bfb4"
version = "0.2.3+0"

[[deps.libaom_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "1827acba325fdcdf1d2647fc8d5301dd9ba43a9d"
uuid = "a4ae2306-e953-59d6-aa16-d00cac43593b"
version = "3.9.0+0"

[[deps.libass_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "HarfBuzz_jll", "JLLWrappers", "Libdl", "Zlib_jll"]
git-tree-sha1 = "e17c115d55c5fbb7e52ebedb427a0dca79d4484e"
uuid = "0ac62f75-1d6f-5e53-bd7c-93b484bb37c0"
version = "0.15.2+0"

[[deps.libblastrampoline_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "8e850b90-86db-534c-a0d3-1478176c7d93"
version = "5.11.0+0"

[[deps.libdecor_jll]]
deps = ["Artifacts", "Dbus_jll", "JLLWrappers", "Libdl", "Libglvnd_jll", "Pango_jll", "Wayland_jll", "xkbcommon_jll"]
git-tree-sha1 = "9bf7903af251d2050b467f76bdbe57ce541f7f4f"
uuid = "1183f4f0-6f2a-5f1a-908b-139f9cdfea6f"
version = "0.2.2+0"

[[deps.libfdk_aac_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "8a22cf860a7d27e4f3498a0fe0811a7957badb38"
uuid = "f638f0a6-7fb0-5443-88ba-1cc74229b280"
version = "2.0.3+0"

[[deps.libpng_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Zlib_jll"]
git-tree-sha1 = "b70c870239dc3d7bc094eb2d6be9b73d27bef280"
uuid = "b53b4c65-9356-5827-b1ea-8c7a1a84506f"
version = "1.6.44+0"

[[deps.libsixel_jll]]
deps = ["Artifacts", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Pkg", "libpng_jll"]
git-tree-sha1 = "7dfa0fd9c783d3d0cc43ea1af53d69ba45c447df"
uuid = "075b6546-f08a-558a-be8f-8157d0f608a5"
version = "1.10.3+1"

[[deps.libvorbis_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Ogg_jll", "Pkg"]
git-tree-sha1 = "490376214c4721cdaca654041f635213c6165cb3"
uuid = "f27f6e37-5d2b-51aa-960f-b287f2bc3b7a"
version = "1.3.7+2"

[[deps.nghttp2_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "8e850ede-7688-5339-a07c-302acd2aaf8d"
version = "1.59.0+0"

[[deps.oneTBB_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "7d0ea0f4895ef2f5cb83645fa689e52cb55cf493"
uuid = "1317d2d5-d96f-522e-a858-c73665f53c3e"
version = "2021.12.0+0"

[[deps.p7zip_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "3f19e933-33d8-53b3-aaab-bd5110c3b7a0"
version = "17.4.0+2"

[[deps.x264_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4fea590b89e6ec504593146bf8b988b2c00922b2"
uuid = "1270edf5-f2f9-52d2-97e9-ab00b5d0237a"
version = "2021.5.5+0"

[[deps.x265_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "ee567a171cce03570d77ad3a43e90218e38937a9"
uuid = "dfaa095f-4041-5dcd-9319-2fabd8486b76"
version = "3.5.0+0"

[[deps.xkbcommon_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Wayland_jll", "Wayland_protocols_jll", "Xorg_libxcb_jll", "Xorg_xkeyboard_config_jll"]
git-tree-sha1 = "9c304562909ab2bab0262639bd4f444d7bc2be37"
uuid = "d8fb68d0-12a3-5cfd-a85a-d49703b185fd"
version = "1.4.1+1"
"""

# ╔═╡ Cell order:
# ╠═292dd262-a364-11eb-053a-8169f9613c46
# ╟─9c3718e9-10bc-4599-8042-ff803367b75a
# ╟─e52318f4-a34a-11eb-0a99-7936c0dd356d
# ╟─797799fa-6418-40e7-a952-9420fb66138c
# ╠═a1306504-a366-11eb-2c57-df5b43eb08c8
# ╟─1065fc10-a365-11eb-3853-e38bf36935d0
# ╟─6e024264-a36c-11eb-3a5b-f1ac308746bc
# ╟─445a67b9-8825-4235-85e7-b8c9fe1b9f64
# ╠═10886362-a368-11eb-259c-b7fc8584e201
# ╠═2d58ce80-a368-11eb-1cac-abbc689d8924
# ╟─14e53455-986a-4d0a-aaad-cf2f0b55aaef
# ╟─8ed6aed4-a37a-11eb-2437-ab230e0d7961
# ╠═4b19b7d6-a372-11eb-053a-6b9b98cf740b
# ╟─997381cf-78cd-4135-8afa-b45b8cb6ca13
# ╠═d3c82d10-a372-11eb-36cf-4503372dbe21
# ╟─87655cba-16d6-4103-830e-e82c83c10ac2
# ╠═fab87028-a373-11eb-0bb2-ffda75bc703d
# ╟─456aafaa-a374-11eb-140e-af2e4385326d
# ╠═25578ccc-a374-11eb-1fdc-47e4266e88bd
# ╟─8eecc8d1-cc5a-4c87-afb7-fe8d38678d55
# ╠═85a629a9-bf53-4f09-a3d8-fd0dec621915
# ╟─94c1a07c-6a15-4814-b0f4-74187016c0fc
# ╠═b0b8f2de-46f7-4a2a-aed4-7d4eee920184
# ╟─48516bec-071e-4aff-a535-e03a6e4c0144
# ╟─e0b3343e-4057-40fa-a23a-127b27c28c52
# ╠═826f5b04-a36c-11eb-03d1-8f5982edfebe
# ╟─875dac3c-a379-11eb-1e21-0729c4722597
# ╟─bc8f9306-a41a-11eb-0ffd-178dcb88d385
# ╟─601b5240-a41a-11eb-236b-2f65c372d6fd
# ╟─a572e9be-a377-11eb-1e31-e158b0432f7b
# ╟─e0e2d32c-925c-4016-ae24-f1d78e1061bc
# ╟─1ecb7048-a377-11eb-3dff-ad2a1c343969
# ╟─3fe0af28-a395-11eb-0b07-330e4db0bda2
# ╟─8d40faae-a3aa-11eb-1fc9-9d64b9cd7f90
# ╟─715eabba-a3a7-11eb-0655-3b3866454bd2
# ╟─de4730e3-cb4a-45f8-a72d-b80bc67f6835
# ╟─0de006b6-a3a6-11eb-3bfb-e5983d01d5d2
# ╟─2f29c296-a3a6-11eb-1933-9d3be03a3367
# ╟─381068d6-4424-446c-92bd-3751cea78edf
# ╟─56800fba-2faa-4046-9fbb-66d51c8a9c60
# ╟─da71a160-0046-4d08-a83a-826a712a1c2a
# ╟─f23ecb85-4c21-42c1-99dd-bf2a26dd48fd
# ╠═20a052ab-c1a4-4b67-80e6-00f3fa1c3a2c
# ╠═c70094da-e622-4380-993e-bf83a734aff0
# ╟─94f75fdf-7d1d-48b2-bf49-c0218075abb3
# ╟─008a130c-b1b2-4c38-a724-add0b5e95fb6
# ╠═1540906e-a3ac-11eb-390d-35d34eae5172
# ╟─c7cd5338-a419-11eb-3e8c-e9e35e50a93a
# ╟─e5d0ccc8-a409-11eb-2064-dd0f3fabed88
# ╠═1130e100-a3ab-11eb-3aca-851eeeb201df
# ╟─af8f8762-59a2-4a77-8bb5-1a1d9a68d742
# ╟─85748df5-2f22-4d95-a974-ca9855aa5462
# ╟─5a4e9672-5cde-4763-bfba-94981d4556b3
# ╟─6986999a-aae6-41c4-847a-29263d5697cb
# ╟─94d173d7-182b-4f97-9969-70427d51aa92
# ╟─ff2bfdbd-1780-4cb2-b560-01909be25888
# ╟─648254c4-c8be-4b60-9f49-ea68e449884f
# ╠═544f0f72-ee21-4efc-b5db-0bb2d10dee2b
# ╠═6f6895e9-5db7-4526-b8a9-9d77bb6f38c1
# ╠═6c3506c6-16de-42a8-a085-0c611386134b
# ╟─cdd8d34a-dc2d-4ef7-94e8-9ee0563da520
# ╟─c629d02d-8a27-42e4-aaa2-f491e6bbb0bc
# ╟─8fa4d7ad-032f-40a8-b4e0-fcc2e41ac0ef
# ╟─41e4ec16-6bc4-40b9-a793-0b4ed74bed0f
# ╟─ed01158c-ad86-4ff0-92ba-801a80f8fd07
# ╟─103d11d7-efac-4c36-8ac2-d8fdc256b484
# ╟─5cee667a-aba3-4be0-8f9f-2b35b15ed7e6
# ╟─9400898f-1462-47fd-95d2-a87db52a0dda
# ╟─f7411d90-e24a-44ed-89c9-c0befaf73d4f
# ╟─54501740-1190-4fc7-8904-06f71b6d45b1
# ╟─dd3ba250-6000-41b1-923c-8d265753b1ba
# ╟─9b3da86d-dcb5-4c5c-8fb8-716e2250367a
# ╟─0c12c0f7-3e93-4616-a137-2dc24b1a0fba
# ╟─79024e33-d6f9-4af6-b321-888947740e09
# ╟─1f4c0ac8-6bd2-4777-80d6-f1b8c155b620
# ╟─00000000-0000-0000-0000-000000000001
# ╟─00000000-0000-0000-0000-000000000002
